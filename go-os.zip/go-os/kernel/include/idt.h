#ifndef GOOS_IDT_H
#define GOOS_IDT_H
#include <stdint.h>

#define IDT_ENTRIES 256
#define IDT_EXCEPTION_VECTORS 32
#define IDT_GATE_INTERRUPT 0x8E /* present, DPL 0, 64-bit interrupt gate */

struct idt_entry {
    uint16_t offset_lo;
    uint16_t selector;
    uint8_t ist;
    uint8_t type_attr;
    uint16_t offset_mid;
    uint32_t offset_hi;
    uint32_t zero;
} __attribute__((packed));

struct idt_ptr {
    uint16_t limit;
    uint64_t base;
} __attribute__((packed));

_Static_assert(sizeof(struct idt_entry) == 16, "IDT gate must be 16 bytes");
_Static_assert(sizeof(struct idt_ptr) == 10, "IDTR operand must be 10 bytes");

static inline struct idt_entry idt_encode_gate(uint64_t handler, uint16_t selector, uint8_t ist,
                                               uint8_t type_attr)
{
    struct idt_entry e;
    e.offset_lo = (uint16_t)(handler & 0xFFFF);
    e.selector = selector;
    e.ist = (uint8_t)(ist & 7);
    e.type_attr = type_attr;
    e.offset_mid = (uint16_t)((handler >> 16) & 0xFFFF);
    e.offset_hi = (uint32_t)(handler >> 32);
    e.zero = 0;
    return e;
}

/* Table of the 32 exception entry stubs (kernel/src/isr.S). */
extern const uint64_t isr_stub_table[IDT_EXCEPTION_VECTORS];

void idt_init(void); /* installs gates 0..31 and loads the IDTR */
#endif
