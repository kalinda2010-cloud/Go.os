#ifndef GOOS_EXCEPTION_H
#define GOOS_EXCEPTION_H
#include <stdbool.h>
#include <stdint.h>

/* Register frame as built by kernel/src/isr.S (lowest address first). */
struct exception_frame {
    uint64_t r15, r14, r13, r12, r11, r10, r9, r8;
    uint64_t rbp, rdi, rsi, rdx, rcx, rbx, rax;
    uint64_t vector, error_code;           /* pushed by the stub */
    uint64_t rip, cs, rflags, rsp, ss;     /* pushed by the CPU */
};
_Static_assert(sizeof(struct exception_frame) == 22 * 8, "frame layout must match isr.S");

#define EXC_BREAKPOINT 3
#define EXC_VECTORS 32

const char *exception_name(unsigned vector);      /* "Page Fault" */
const char *exception_mnemonic(unsigned vector);  /* "#PF" */
bool exception_has_error_code(unsigned vector);

/* Called from isr.S. Returns only for recoverable traps (#BP). */
void exception_dispatch(struct exception_frame *frame);
#endif
