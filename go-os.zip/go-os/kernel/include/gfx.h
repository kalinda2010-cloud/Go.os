#ifndef GOOS_GFX_H
#define GOOS_GFX_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define GFX_FONT_W 8
#define GFX_FONT_H 8
#define GFX_MAX_DIM 16384u
#define GFX_MAX_PITCH (1u << 20)
#define GFX_MEMORY_MODEL_RGB 1

struct gfx_fb {
    uint8_t *base;
    uint32_t width, height, pitch; /* pitch in bytes */
    uint8_t bpp, bytes_pp;
    uint8_t r_size, r_shift, g_size, g_shift, b_size, b_shift;
};

enum gfx_fb_status {
    GFX_FB_OK = 0,
    GFX_FB_NO_ADDRESS,
    GFX_FB_BAD_SIZE,
    GFX_FB_BAD_MODEL,
    GFX_FB_BAD_BPP,
    GFX_FB_BAD_MASKS,
    GFX_FB_BAD_PITCH,
};

const char *gfx_fb_status_str(enum gfx_fb_status st);

/* masks = { r_size, r_shift, g_size, g_shift, b_size, b_shift } */
enum gfx_fb_status gfx_fb_setup(struct gfx_fb *fb, void *address, uint64_t width, uint64_t height,
                                uint64_t pitch, uint64_t bpp, uint64_t memory_model,
                                const uint8_t masks[6]);

/* Convert 0xRRGGBB into the framebuffer's native pixel layout. */
static inline uint32_t gfx_pack_rgb(const struct gfx_fb *fb, uint32_t rgb)
{
    uint32_t r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
    return ((r >> (8 - fb->r_size)) << fb->r_shift) | ((g >> (8 - fb->g_size)) << fb->g_shift) |
           ((b >> (8 - fb->b_size)) << fb->b_shift);
}

/* All drawing takes *packed* pixel values (see gfx_pack_rgb) except gradients. */
void gfx_fill_rect(const struct gfx_fb *fb, int x, int y, int w, int h, uint32_t px);
void gfx_vgradient(const struct gfx_fb *fb, int x, int y, int w, int h, uint32_t rgb_top,
                   uint32_t rgb_bottom);
void gfx_fill_circle(const struct gfx_fb *fb, int cx, int cy, int r, uint32_t px);
void gfx_draw_ring(const struct gfx_fb *fb, int cx, int cy, int r_outer, int r_inner, uint32_t px);
void gfx_draw_glyph(const struct gfx_fb *fb, int x, int y, unsigned char ch, int scale, uint32_t fg,
                    uint32_t bg, bool opaque);
void gfx_draw_text_n(const struct gfx_fb *fb, int x, int y, const char *s, size_t max_chars,
                     int scale, uint32_t fg, uint32_t bg, bool opaque);
void gfx_draw_text(const struct gfx_fb *fb, int x, int y, const char *s, int scale, uint32_t fg,
                   uint32_t bg, bool opaque);
int gfx_text_width(const char *s, int scale);

#endif
