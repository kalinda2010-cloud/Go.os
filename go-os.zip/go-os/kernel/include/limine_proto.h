#ifndef GOOS_LIMINE_PROTO_H
#define GOOS_LIMINE_PROTO_H

/*
 * Minimal subset of the Limine boot protocol ABI (x86_64) used by GO.OS.
 *
 * Written from the protocol specification so the kernel does not depend on the
 * macro names of a particular limine.h release. What the bootloader cares about
 * is the memory layout: the magic numbers and structure layouts below.
 * `make check-protocol` compares the magic numbers against an official
 * limine.h once Limine has been fetched.
 */

#include <stddef.h>
#include <stdint.h>

#define LIMINE_COMMON_MAGIC_0 0xc7b1dd30df4c8b88ULL
#define LIMINE_COMMON_MAGIC_1 0x0a82e883a194f07bULL

/* Every request starts with { common magic 0, common magic 1, id 0, id 1 }. */
#define LIMINE_REQUEST_ID(a, b) { LIMINE_COMMON_MAGIC_0, LIMINE_COMMON_MAGIC_1, (a), (b) }

/* Base revision tag: { magic 0, magic 1, revision } */
#define LIMINE_BASE_REVISION_MAGIC_0 0xf9562b2d5c95a6c8ULL
#define LIMINE_BASE_REVISION_MAGIC_1 0x6a7b384944536bdcULL
#define LIMINE_BASE_REVISION_INIT(rev) \
    { LIMINE_BASE_REVISION_MAGIC_0, LIMINE_BASE_REVISION_MAGIC_1, (rev) }

/* Markers delimiting the area the bootloader scans for requests. */
#define LIMINE_REQUESTS_START_MARKER_INIT \
    { 0xf6b8f4b39de7d1aeULL, 0xfab91a6940fcb9cfULL, 0x785c6ed015d3e316ULL, 0x181e920a7852b9d9ULL }
#define LIMINE_REQUESTS_END_MARKER_INIT \
    { 0xadc0e0531bb10d03ULL, 0x9572709f31764c62ULL }

#define LIMINE_BOOTLOADER_INFO_REQUEST_ID LIMINE_REQUEST_ID(0xf55038d8e2a1202fULL, 0x279426fcf5f59740ULL)
#define LIMINE_FIRMWARE_TYPE_REQUEST_ID   LIMINE_REQUEST_ID(0x8c2f75d90bef28a8ULL, 0x7045a4688eac00c3ULL)
#define LIMINE_HHDM_REQUEST_ID            LIMINE_REQUEST_ID(0x48dcf1cb8ad2b852ULL, 0x63984e959a98244bULL)
#define LIMINE_FRAMEBUFFER_REQUEST_ID     LIMINE_REQUEST_ID(0x9d5827dcd881dd75ULL, 0xa3148604f6fab11bULL)
#define LIMINE_MEMMAP_REQUEST_ID          LIMINE_REQUEST_ID(0x67cf3d9d378a806fULL, 0xe304acdfc50c3c62ULL)

struct limine_bootloader_info_response { uint64_t revision; const char *name; const char *version; };
struct limine_bootloader_info_request {
    uint64_t id[4]; uint64_t revision; const struct limine_bootloader_info_response *response;
};

#define LIMINE_FIRMWARE_TYPE_X86BIOS 0
#define LIMINE_FIRMWARE_TYPE_EFI32   1
#define LIMINE_FIRMWARE_TYPE_EFI64   2
struct limine_firmware_type_response { uint64_t revision; uint64_t firmware_type; };
struct limine_firmware_type_request {
    uint64_t id[4]; uint64_t revision; const struct limine_firmware_type_response *response;
};

struct limine_hhdm_response { uint64_t revision; uint64_t offset; };
struct limine_hhdm_request {
    uint64_t id[4]; uint64_t revision; const struct limine_hhdm_response *response;
};

#define LIMINE_FRAMEBUFFER_RGB 1
struct limine_framebuffer {
    void *address;
    uint64_t width;
    uint64_t height;
    uint64_t pitch;
    uint16_t bpp;
    uint8_t memory_model;
    uint8_t red_mask_size;
    uint8_t red_mask_shift;
    uint8_t green_mask_size;
    uint8_t green_mask_shift;
    uint8_t blue_mask_size;
    uint8_t blue_mask_shift;
    uint8_t unused[7];
    uint64_t edid_size;
    void *edid;
    /* newer response revisions append more fields; never read here */
};
struct limine_framebuffer_response {
    uint64_t revision;
    uint64_t framebuffer_count;
    struct limine_framebuffer **framebuffers;
};
struct limine_framebuffer_request {
    uint64_t id[4]; uint64_t revision; const struct limine_framebuffer_response *response;
};

#define LIMINE_MEMMAP_USABLE                 0
#define LIMINE_MEMMAP_RESERVED               1
#define LIMINE_MEMMAP_ACPI_RECLAIMABLE       2
#define LIMINE_MEMMAP_ACPI_NVS               3
#define LIMINE_MEMMAP_BAD_MEMORY             4
#define LIMINE_MEMMAP_BOOTLOADER_RECLAIMABLE 5
#define LIMINE_MEMMAP_EXECUTABLE_AND_MODULES 6
#define LIMINE_MEMMAP_FRAMEBUFFER            7
struct limine_memmap_entry { uint64_t base; uint64_t length; uint64_t type; };
struct limine_memmap_response {
    uint64_t revision; uint64_t entry_count; struct limine_memmap_entry **entries;
};
struct limine_memmap_request {
    uint64_t id[4]; uint64_t revision; const struct limine_memmap_response *response;
};

_Static_assert(sizeof(void *) == 8, "Limine structures assume 64-bit pointers");
_Static_assert(offsetof(struct limine_framebuffer, width) == 8, "fb.width");
_Static_assert(offsetof(struct limine_framebuffer, pitch) == 24, "fb.pitch");
_Static_assert(offsetof(struct limine_framebuffer, bpp) == 32, "fb.bpp");
_Static_assert(offsetof(struct limine_framebuffer, memory_model) == 34, "fb.memory_model");
_Static_assert(offsetof(struct limine_framebuffer, red_mask_size) == 35, "fb.red_mask_size");
_Static_assert(offsetof(struct limine_framebuffer, blue_mask_shift) == 40, "fb.blue_mask_shift");
_Static_assert(offsetof(struct limine_framebuffer, edid_size) == 48, "fb.edid_size");
_Static_assert(sizeof(struct limine_framebuffer_request) == 48, "request size");
_Static_assert(offsetof(struct limine_framebuffer_request, response) == 40, "request.response");

#endif
