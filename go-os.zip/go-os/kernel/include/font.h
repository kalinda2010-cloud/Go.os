#ifndef GOOS_FONT_H
#define GOOS_FONT_H
#include <stdint.h>
/* 8x8 bitmap font, ASCII 0x20..0x7E; bit 0 of each row byte = leftmost pixel. */
extern const uint8_t font8x8_basic[95][8];
const uint8_t *font_glyph(unsigned char c);
#endif
