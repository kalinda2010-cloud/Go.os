#ifndef GOOS_KPRINTF_H
#define GOOS_KPRINTF_H
#include <stdarg.h>
#include <stddef.h>

/*
 * Small printf subset: %% %c %s %d %i %u %x %X %o %p, flags '-' and '0',
 * width, '.precision', '*' and length modifiers hh h l ll z t j.
 * Semantics follow snprintf (always NUL-terminates, returns the full length).
 */
int kvsnprintf(char *buf, size_t size, const char *fmt, va_list ap);
int ksnprintf(char *buf, size_t size, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
#endif
