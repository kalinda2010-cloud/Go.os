#ifndef GOOS_PANIC_H
#define GOOS_PANIC_H

#include "exception.h"
#include "gfx.h"
#include <stdint.h>

#define PANIC_MAX_LINES 32
#define PANIC_LINE_MAX 96

struct panic_report {
    const char *title;
    char lines[PANIC_MAX_LINES][PANIC_LINE_MAX];
    unsigned nlines;
};

struct cpu_regs_snapshot {
    uint64_t cr0, cr2, cr3, cr4;
};

/* Portable (host-testable) parts */
void panic_build_exception_report(struct panic_report *r, const struct exception_frame *f,
                                  const struct cpu_regs_snapshot *cr);
void panic_render(const struct gfx_fb *fb, const struct panic_report *r);

/* Kernel-only: print on serial + framebuffer, then halt the CPU forever. */
__attribute__((noreturn)) void panic_exception(const struct exception_frame *f);
__attribute__((noreturn, format(printf, 1, 2))) void kpanic(const char *fmt, ...);
#endif
