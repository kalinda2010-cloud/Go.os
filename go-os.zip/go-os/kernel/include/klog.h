#ifndef GOOS_KLOG_H
#define GOOS_KLOG_H

enum klog_level { KLOG_INFO = 0, KLOG_OK, KLOG_WARN, KLOG_FAIL };
typedef void (*klog_sink_fn)(enum klog_level level, const char *text);

/* Every line goes to the serial port; if a sink is attached it gets it too.
 * Lines logged before a sink exists are buffered and replayed on attach. */
void klog(enum klog_level level, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
void klog_attach_sink(klog_sink_fn fn);
const char *klog_level_tag(enum klog_level level); /* "[ OK ]" etc, always 6 chars */
void klog_reset(void);                              /* tests only */
#endif
