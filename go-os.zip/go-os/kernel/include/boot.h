#ifndef GOOS_BOOT_H
#define GOOS_BOOT_H

#include "gfx.h"
#include "limine_proto.h"
#include <stdbool.h>
#include <stdint.h>

enum boot_firmware { BOOT_FW_UNKNOWN = 0, BOOT_FW_BIOS, BOOT_FW_EFI32, BOOT_FW_EFI64 };

/* Raw view of what the bootloader answered (all pointers may be NULL). */
struct boot_raw {
    uint64_t base_rev_requested;
    uint64_t base_rev[3];
    const struct limine_framebuffer_response *framebuffer;
    const struct limine_hhdm_response *hhdm;
    const struct limine_memmap_response *memmap;
    const struct limine_bootloader_info_response *loader;
    const struct limine_firmware_type_response *firmware;
};

/* Validated, bootloader-independent boot information. */
struct boot_info {
    bool base_rev_supported;
    bool base_rev_loaded_valid;
    uint64_t base_rev_requested, base_rev_loaded;

    bool fb_valid;
    const char *fb_problem; /* why there is no usable framebuffer (NULL if fb_valid) */
    struct gfx_fb fb;

    bool have_loader;
    char loader_name[32], loader_version[32];
    enum boot_firmware firmware;
    bool have_hhdm;
    uint64_t hhdm_offset;
    bool have_memmap;
    uint32_t memmap_entries;
    uint64_t mem_usable_bytes;
};

/* Pure parsing (unit-tested on the host): never dereferences NULL, never traps. */
void boot_parse(struct boot_info *bi, const struct boot_raw *raw);
/* Reads the Limine request objects embedded in the kernel image. */
void boot_collect(struct boot_info *bi);
#endif
