#ifndef GOOS_BOOT_SEQUENCE_H
#define GOOS_BOOT_SEQUENCE_H
#include "boot.h"
#include <stdbool.h>

/* What kmain already did before the boot screen could exist. */
struct early_status {
    bool serial_ok;
    bool idt_ok;
    unsigned idt_vectors;
};

/* Shows the boot screen (if there is a framebuffer) and logs the boot status. */
void kernel_boot_sequence(const struct boot_info *bi, const struct early_status *early);
#endif
