#ifndef GOOS_SERIAL_H
#define GOOS_SERIAL_H
#include <stdbool.h>

void serial_init(void);     /* probes COM1 with a loopback test */
bool serial_present(void);
void serial_putc(char c);
void serial_puts(const char *s);
#endif
