#ifndef GOOS_VERSION_H
#define GOOS_VERSION_H

#define GOOS_NAME                 "GO.OS"
#define GOOS_VERSION              "0.1.0"
#define GOOS_VENDOR               "GO.Dev"
#define GOOS_MILESTONE            1
#define GOOS_MILESTONE_NAME       "Kernel Boot"

/* Limine base revision the kernel asks for (3 = Limine v8.x and newer). */
#define GOOS_LIMINE_BASE_REVISION 3

#endif
