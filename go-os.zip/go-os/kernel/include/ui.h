#ifndef GOOS_UI_H
#define GOOS_UI_H

#include "gfx.h"
#include "klog.h"
#include <stdbool.h>

struct ui_layout {
    int ts;                     /* text scale */
    int cell, line_h;           /* glyph cell size, log line pitch */
    int ring_cx, ring_cy, ring_r;
    int title_scale, title_w, title_x, title_y;
    int sub_y;
    int bar_x, bar_y, bar_w, bar_h;
    int log_x, log_y, log_w, log_h, log_pad, log_cols, log_rows;
    int foot_y;
    int total_h;                /* height of the whole composition */
};

void ui_compute_layout(struct ui_layout *l, int width, int height);

/* Draws the GO.OS boot screen on `fb` and starts accepting log lines. */
void ui_attach(const struct gfx_fb *fb);
bool ui_attached(void);
const struct gfx_fb *ui_framebuffer(void); /* NULL if not attached */
void ui_log(enum klog_level level, const char *text); /* klog sink */
void ui_set_progress(unsigned percent);
void ui_reset(void);                                  /* tests only */
#endif
