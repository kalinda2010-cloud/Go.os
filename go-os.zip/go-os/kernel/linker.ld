/* GO.OS kernel linker script: higher-half ELF64 for the Limine boot protocol. */
OUTPUT_FORMAT(elf64-x86-64)
OUTPUT_ARCH(i386:x86-64)
ENTRY(_start)

/* Separate PT_LOAD segments so Limine maps R-X / R-- / RW- correctly. */
PHDRS
{
    requests PT_LOAD FLAGS(6);  /* RW  - Limine writes request responses here */
    text     PT_LOAD FLAGS(5);  /* R-X */
    rodata   PT_LOAD FLAGS(4);  /* R-- */
    data     PT_LOAD FLAGS(6);  /* RW  - .data + .bss */
}

SECTIONS
{
    . = 0xffffffff80000000;
    __kernel_start = .;

    .limine_requests : {
        KEEP(*(.limine_requests_start))
        KEEP(*(.limine_requests))
        KEEP(*(.limine_requests_end))
    } :requests

    . = ALIGN(CONSTANT(MAXPAGESIZE));
    .text : { *(.text .text.*) } :text

    . = ALIGN(CONSTANT(MAXPAGESIZE));
    .rodata : { *(.rodata .rodata.*) } :rodata

    . = ALIGN(CONSTANT(MAXPAGESIZE));
    .data : { *(.data .data.*) } :data

    /* .bss must be last in :data so no zeros are stored in the file. */
    .bss : {
        *(.bss .bss.*)
        *(COMMON)
    } :data

    __kernel_end = .;

    /DISCARD/ : {
        *(.eh_frame*)
        *(.note .note.*)
        *(.comment)
    }
}
