#include "boot.h"

static void copy_str(char *dst, size_t cap, const char *src)
{
    size_t i = 0;
    if (src) {
        for (; src[i] && i + 1 < cap; i++)
            dst[i] = src[i];
    }
    dst[i] = '\0';
}

void boot_parse(struct boot_info *bi, const struct boot_raw *raw)
{
    char *p = (char *)bi;
    for (size_t i = 0; i < sizeof *bi; i++)
        p[i] = 0;

    bi->base_rev_requested = raw->base_rev_requested;
    bi->base_rev_supported = (raw->base_rev[2] == 0);
    if (raw->base_rev[1] != LIMINE_BASE_REVISION_MAGIC_1) {
        bi->base_rev_loaded_valid = true;
        bi->base_rev_loaded = raw->base_rev[1];
    }

    /* Framebuffer: every way it can be missing or unusable ends in a reason string. */
    bi->fb_problem = "bootloader gave no framebuffer response";
    const struct limine_framebuffer_response *fr = raw->framebuffer;
    if (fr) {
        if (fr->framebuffer_count == 0 || fr->framebuffers == NULL) {
            bi->fb_problem = "bootloader reported zero framebuffers";
        } else if (fr->framebuffers[0] == NULL) {
            bi->fb_problem = "framebuffer descriptor is NULL";
        } else {
            const struct limine_framebuffer *f = fr->framebuffers[0];
            const uint8_t masks[6] = { f->red_mask_size,   f->red_mask_shift,  f->green_mask_size,
                                       f->green_mask_shift, f->blue_mask_size, f->blue_mask_shift };
            enum gfx_fb_status st = gfx_fb_setup(&bi->fb, f->address, f->width, f->height, f->pitch,
                                                 f->bpp, f->memory_model, masks);
            if (st == GFX_FB_OK) {
                bi->fb_valid = true;
                bi->fb_problem = NULL;
            } else {
                bi->fb_problem = gfx_fb_status_str(st);
            }
        }
    }

    if (raw->loader) {
        bi->have_loader = true;
        copy_str(bi->loader_name, sizeof bi->loader_name, raw->loader->name);
        copy_str(bi->loader_version, sizeof bi->loader_version, raw->loader->version);
    }

    bi->firmware = BOOT_FW_UNKNOWN;
    if (raw->firmware) {
        switch (raw->firmware->firmware_type) {
        case LIMINE_FIRMWARE_TYPE_X86BIOS: bi->firmware = BOOT_FW_BIOS; break;
        case LIMINE_FIRMWARE_TYPE_EFI32: bi->firmware = BOOT_FW_EFI32; break;
        case LIMINE_FIRMWARE_TYPE_EFI64: bi->firmware = BOOT_FW_EFI64; break;
        default: break;
        }
    }

    if (raw->hhdm) {
        bi->have_hhdm = true;
        bi->hhdm_offset = raw->hhdm->offset;
    }

    const struct limine_memmap_response *mm = raw->memmap;
    if (mm && mm->entries) {
        bi->have_memmap = true;
        for (uint64_t i = 0; i < mm->entry_count; i++) {
            const struct limine_memmap_entry *e = mm->entries[i];
            if (!e)
                continue;
            bi->memmap_entries++;
            if (e->type == LIMINE_MEMMAP_USABLE || e->type == LIMINE_MEMMAP_BOOTLOADER_RECLAIMABLE)
                bi->mem_usable_bytes += e->length;
        }
    }
}
