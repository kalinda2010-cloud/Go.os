#include "boot.h"
#include "boot_sequence.h"
#include "cpu.h"
#include "idt.h"
#include "klog.h"
#include "serial.h"

/*
 * Optional exception self-test, compiled in with `make TEST_FAULT=<kind>`:
 *   div0 | ud2 | gp | pf  -> must end in the kernel panic screen
 *   bp                    -> handler logs and the kernel continues
 */
static void run_selftest_fault(void)
{
#if defined(GOOS_TEST_FAULT_DIV0)
    klog(KLOG_WARN, "TEST_FAULT=div0: raising #DE");
    volatile int zero = 0;
    volatile int r = 1 / zero;
    (void)r;
#elif defined(GOOS_TEST_FAULT_UD2)
    klog(KLOG_WARN, "TEST_FAULT=ud2: raising #UD");
    __asm__ volatile("ud2");
#elif defined(GOOS_TEST_FAULT_BP)
    klog(KLOG_WARN, "TEST_FAULT=bp: raising #BP");
    __asm__ volatile("int3");
    klog(KLOG_OK, "returned from the #BP handler");
#elif defined(GOOS_TEST_FAULT_GP)
    klog(KLOG_WARN, "TEST_FAULT=gp: raising #GP");
    *(volatile uint64_t *)0x8000000000000000ULL = 0; /* non-canonical address */
#elif defined(GOOS_TEST_FAULT_PF)
    klog(KLOG_WARN, "TEST_FAULT=pf: raising #PF");
    *(volatile uint64_t *)0x00000000deadb000ULL = 0; /* unmapped low address */
#endif
}

void kmain(void)
{
    struct early_status early = { 0 };

    serial_init();
    early.serial_ok = serial_present();

    idt_init(); /* from here on, CPU exceptions end in a readable panic */
    early.idt_ok = true;
    early.idt_vectors = IDT_EXCEPTION_VECTORS;

    struct boot_info bi;
    boot_collect(&bi);
    kernel_boot_sequence(&bi, &early);

    run_selftest_fault();

    cpu_halt_forever();
}
