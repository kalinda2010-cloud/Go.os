#include "serial.h"
#include "cpu.h"

#define COM1 0x3F8

static bool serial_ok;

void serial_init(void)
{
    outb(COM1 + 1, 0x00); /* no interrupts */
    outb(COM1 + 3, 0x80); /* DLAB on */
    outb(COM1 + 0, 0x01); /* divisor 1 = 115200 baud */
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03); /* 8N1, DLAB off */
    outb(COM1 + 2, 0xC7); /* FIFO on, cleared */
    outb(COM1 + 4, 0x1E); /* loopback self-test */
    outb(COM1 + 0, 0xAE);
    if (inb(COM1 + 0) != 0xAE) {
        serial_ok = false; /* no UART: stay silent instead of spinning forever later */
        return;
    }
    outb(COM1 + 4, 0x0F); /* normal operation */
    serial_ok = true;
}

bool serial_present(void) { return serial_ok; }

void serial_putc(char c)
{
    if (!serial_ok)
        return;
    for (unsigned spins = 0; !(inb(COM1 + 5) & 0x20); spins++) {
        if (spins > 200000)
            return; /* transmitter stuck: drop the byte, never hang the kernel */
    }
    outb(COM1, (uint8_t)c);
}

void serial_puts(const char *s)
{
    while (s && *s)
        serial_putc(*s++);
}
