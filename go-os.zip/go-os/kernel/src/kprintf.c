#include "kprintf.h"
#include <stdbool.h>
#include <stdint.h>

struct out {
    char *buf;
    size_t size;
    size_t len;
};

static void out_ch(struct out *o, char c)
{
    if (o->size && o->len < o->size - 1)
        o->buf[o->len] = c;
    o->len++;
}

static void out_pad(struct out *o, char c, int n)
{
    while (n-- > 0)
        out_ch(o, c);
}

static void fmt_num(struct out *o, unsigned long long v, unsigned base, bool upper,
                    const char *prefix, int width, bool left, bool zero, int prec)
{
    char tmp[24];
    int n = 0;
    const char *dig = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    if (v == 0 && prec != 0)
        tmp[n++] = '0';
    while (v) {
        tmp[n++] = dig[v % base];
        v /= base;
    }
    int plen = 0;
    while (prefix[plen])
        plen++;
    int zeros = prec > n ? prec - n : 0;
    int total = plen + zeros + n;
    int pad = width > total ? width - total : 0;
    if (zero && !left && prec < 0) {
        zeros += pad;
        pad = 0;
    }
    if (!left)
        out_pad(o, ' ', pad);
    for (int i = 0; i < plen; i++)
        out_ch(o, prefix[i]);
    out_pad(o, '0', zeros);
    while (n > 0)
        out_ch(o, tmp[--n]);
    if (left)
        out_pad(o, ' ', pad);
}

static void fmt_str(struct out *o, const char *s, int len, int width, bool left)
{
    int pad = width > len ? width - len : 0;
    if (!left)
        out_pad(o, ' ', pad);
    for (int i = 0; i < len; i++)
        out_ch(o, s[i]);
    if (left)
        out_pad(o, ' ', pad);
}

int kvsnprintf(char *buf, size_t size, const char *fmt, va_list ap)
{
    struct out o = { buf, size, 0 };

    for (; *fmt; fmt++) {
        if (*fmt != '%') {
            out_ch(&o, *fmt);
            continue;
        }
        fmt++;

        bool left = false, zero = false;
        for (;; fmt++) {
            if (*fmt == '-') left = true;
            else if (*fmt == '0') zero = true;
            else break;
        }
        int width = 0;
        if (*fmt == '*') {
            width = va_arg(ap, int);
            if (width < 0) { left = true; width = -width; }
            fmt++;
        } else {
            while (*fmt >= '0' && *fmt <= '9')
                width = width * 10 + (*fmt++ - '0');
        }
        int prec = -1;
        if (*fmt == '.') {
            fmt++;
            prec = 0;
            if (*fmt == '*') {
                prec = va_arg(ap, int);
                if (prec < 0) prec = -1;
                fmt++;
            } else {
                while (*fmt >= '0' && *fmt <= '9')
                    prec = prec * 10 + (*fmt++ - '0');
            }
        }
        int lng = 0; /* -2 char, -1 short, 0 int, 1 long, 2 long long */
        for (;; fmt++) {
            if (*fmt == 'h') lng = (lng == -1) ? -2 : -1;
            else if (*fmt == 'l') lng = (lng == 1) ? 2 : 1;
            else if (*fmt == 'z' || *fmt == 't' || *fmt == 'j') lng = 1; /* LP64 */
            else break;
        }

        switch (*fmt) {
        case '%':
            out_ch(&o, '%');
            break;
        case 'c': {
            char ch = (char)va_arg(ap, int);
            fmt_str(&o, &ch, 1, width, left);
            break;
        }
        case 's': {
            const char *s = va_arg(ap, const char *);
            if (!s)
                s = "(null)";
            int len = 0;
            while (s[len] && (prec < 0 || len < prec))
                len++;
            fmt_str(&o, s, len, width, left);
            break;
        }
        case 'd':
        case 'i': {
            long long v;
            if (lng == 2) v = va_arg(ap, long long);
            else if (lng == 1) v = va_arg(ap, long);
            else if (lng == -1) v = (short)va_arg(ap, int);
            else if (lng == -2) v = (signed char)va_arg(ap, int);
            else v = va_arg(ap, int);
            bool neg = v < 0;
            unsigned long long uv = neg ? 0ULL - (unsigned long long)v : (unsigned long long)v;
            fmt_num(&o, uv, 10, false, neg ? "-" : "", width, left, zero, prec);
            break;
        }
        case 'u':
        case 'x':
        case 'X':
        case 'o': {
            unsigned long long uv;
            if (lng == 2) uv = va_arg(ap, unsigned long long);
            else if (lng == 1) uv = va_arg(ap, unsigned long);
            else if (lng == -1) uv = (unsigned short)va_arg(ap, unsigned int);
            else if (lng == -2) uv = (unsigned char)va_arg(ap, unsigned int);
            else uv = va_arg(ap, unsigned int);
            unsigned base = (*fmt == 'u') ? 10 : (*fmt == 'o') ? 8 : 16;
            fmt_num(&o, uv, base, *fmt == 'X', "", width, left, zero, prec);
            break;
        }
        case 'p': {
            uintptr_t v = (uintptr_t)va_arg(ap, void *);
            fmt_num(&o, v, 16, false, "0x", width, left, zero, prec);
            break;
        }
        case '\0':
            fmt--; /* dangling '%' at end of string: stop cleanly */
            break;
        default:
            out_ch(&o, '%');
            out_ch(&o, *fmt);
            break;
        }
    }

    if (o.size)
        o.buf[o.len < o.size ? o.len : o.size - 1] = '\0';
    return (int)o.len;
}

int ksnprintf(char *buf, size_t size, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    int n = kvsnprintf(buf, size, fmt, ap);
    va_end(ap);
    return n;
}
