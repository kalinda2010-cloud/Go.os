/* GO.OS kernel entry point. Limine jumps here in 64-bit long mode, IF=0. */
    .section .text
    .global _start
    .type _start, @function
_start:
    cli
    cld
    leaq    kernel_stack_top(%rip), %rsp   /* own stack, 16-byte aligned */
    xorl    %ebp, %ebp
    call    kmain
.Lhang:
    cli
    hlt
    jmp     .Lhang
    .size _start, . - _start

    .section .bss
    .balign 16
    .global kernel_stack_bottom
kernel_stack_bottom:
    .skip   65536
    .global kernel_stack_top
kernel_stack_top:

    .section .note.GNU-stack,"",@progbits
