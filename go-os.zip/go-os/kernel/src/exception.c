#include "exception.h"
#include "klog.h"
#include "panic.h"

void exception_dispatch(struct exception_frame *f)
{
    if (f->vector == EXC_BREAKPOINT) {
        klog(KLOG_INFO, "#BP breakpoint at %p (continuing)", (void *)(uintptr_t)f->rip);
        return;
    }
    panic_exception(f); /* every other exception is fatal in Milestone 1 */
}
