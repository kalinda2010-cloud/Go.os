#include "gfx.h"
#include "font.h"

const char *gfx_fb_status_str(enum gfx_fb_status st)
{
    switch (st) {
    case GFX_FB_OK: return "ok";
    case GFX_FB_NO_ADDRESS: return "framebuffer address is NULL";
    case GFX_FB_BAD_SIZE: return "invalid framebuffer dimensions";
    case GFX_FB_BAD_MODEL: return "unsupported memory model (not RGB)";
    case GFX_FB_BAD_BPP: return "unsupported bits per pixel";
    case GFX_FB_BAD_MASKS: return "invalid colour mask layout";
    case GFX_FB_BAD_PITCH: return "invalid pitch";
    }
    return "unknown framebuffer error";
}

enum gfx_fb_status gfx_fb_setup(struct gfx_fb *fb, void *address, uint64_t width, uint64_t height,
                                uint64_t pitch, uint64_t bpp, uint64_t memory_model,
                                const uint8_t masks[6])
{
    if (address == NULL)
        return GFX_FB_NO_ADDRESS;
    if (width == 0 || height == 0 || width > GFX_MAX_DIM || height > GFX_MAX_DIM)
        return GFX_FB_BAD_SIZE;
    if (memory_model != GFX_MEMORY_MODEL_RGB)
        return GFX_FB_BAD_MODEL;
    if (bpp != 15 && bpp != 16 && bpp != 24 && bpp != 32)
        return GFX_FB_BAD_BPP;

    uint32_t bytes_pp = (uint32_t)((bpp + 7) / 8);
    if (pitch < width * bytes_pp || pitch > GFX_MAX_PITCH)
        return GFX_FB_BAD_PITCH;

    uint8_t m[6];
    for (int i = 0; i < 6; i++)
        m[i] = masks[i];
    /* Some loaders leave the masks zeroed on plain 32-bit modes: assume XRGB8888. */
    if (bpp == 32 && !m[0] && !m[2] && !m[4]) {
        m[0] = 8; m[1] = 16; m[2] = 8; m[3] = 8; m[4] = 8; m[5] = 0;
    }
    for (int i = 0; i < 6; i += 2) {
        if (m[i] < 1 || m[i] > 8 || (uint32_t)m[i] + m[i + 1] > bytes_pp * 8)
            return GFX_FB_BAD_MASKS;
    }

    fb->base = (uint8_t *)address;
    fb->width = (uint32_t)width;
    fb->height = (uint32_t)height;
    fb->pitch = (uint32_t)pitch;
    fb->bpp = (uint8_t)bpp;
    fb->bytes_pp = (uint8_t)bytes_pp;
    fb->r_size = m[0]; fb->r_shift = m[1];
    fb->g_size = m[2]; fb->g_shift = m[3];
    fb->b_size = m[4]; fb->b_shift = m[5];
    return GFX_FB_OK;
}

static void fill_span(const struct gfx_fb *fb, uint8_t *p, uint32_t count, uint32_t px)
{
    switch (fb->bytes_pp) {
    case 4: {
#if defined(__x86_64__)
        uint64_t n = count; /* full-width count: rep uses all of RCX */
        __asm__ volatile("rep stosl" : "+D"(p), "+c"(n) : "a"(px) : "memory");
#else
        volatile uint32_t *d = (volatile uint32_t *)p;
        while (count--)
            *d++ = px;
#endif
        break;
    }
    case 3: {
        volatile uint8_t *d = p;
        while (count--) {
            d[0] = (uint8_t)px;
            d[1] = (uint8_t)(px >> 8);
            d[2] = (uint8_t)(px >> 16);
            d += 3;
        }
        break;
    }
    case 2: {
        volatile uint16_t *d = (volatile uint16_t *)p;
        while (count--)
            *d++ = (uint16_t)px;
        break;
    }
    default:
        break;
    }
}

void gfx_fill_rect(const struct gfx_fb *fb, int x, int y, int w, int h, uint32_t px)
{
    if (!fb || !fb->base || w <= 0 || h <= 0)
        return;
    int x0 = x, y0 = y, x1 = x + w, y1 = y + h;
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > (int)fb->width) x1 = (int)fb->width;
    if (y1 > (int)fb->height) y1 = (int)fb->height;
    if (x0 >= x1 || y0 >= y1)
        return;
    for (int yy = y0; yy < y1; yy++)
        fill_span(fb, fb->base + (size_t)yy * fb->pitch + (size_t)x0 * fb->bytes_pp,
                  (uint32_t)(x1 - x0), px);
}

static uint32_t lerp_rgb(uint32_t a, uint32_t b, int num, int den)
{
    uint32_t out = 0;
    for (int shift = 16; shift >= 0; shift -= 8) {
        int ca = (int)((a >> shift) & 0xFF), cb = (int)((b >> shift) & 0xFF);
        out |= (uint32_t)(ca + (cb - ca) * num / den) << shift;
    }
    return out;
}

void gfx_vgradient(const struct gfx_fb *fb, int x, int y, int w, int h, uint32_t rgb_top,
                   uint32_t rgb_bottom)
{
    if (!fb || h <= 0)
        return;
    int den = h > 1 ? h - 1 : 1;
    for (int row = 0; row < h; row++)
        gfx_fill_rect(fb, x, y + row, w, 1, gfx_pack_rgb(fb, lerp_rgb(rgb_top, rgb_bottom, row, den)));
}

static uint32_t isqrt_u32(uint32_t n)
{
    uint32_t res = 0, bit = 1u << 30;
    while (bit > n)
        bit >>= 2;
    while (bit) {
        if (n >= res + bit) {
            n -= res + bit;
            res = (res >> 1) + bit;
        } else {
            res >>= 1;
        }
        bit >>= 2;
    }
    return res;
}

void gfx_fill_circle(const struct gfx_fb *fb, int cx, int cy, int r, uint32_t px)
{
    if (r <= 0)
        return;
    for (int dy = -r; dy <= r; dy++) {
        int dx = (int)isqrt_u32((uint32_t)(r * r - dy * dy));
        gfx_fill_rect(fb, cx - dx, cy + dy, 2 * dx + 1, 1, px);
    }
}

void gfx_draw_ring(const struct gfx_fb *fb, int cx, int cy, int r_outer, int r_inner, uint32_t px)
{
    if (r_outer <= 0 || r_inner >= r_outer)
        return;
    if (r_inner < 0)
        r_inner = 0;
    for (int dy = -r_outer; dy <= r_outer; dy++) {
        int ady = dy < 0 ? -dy : dy;
        int xo = (int)isqrt_u32((uint32_t)(r_outer * r_outer - dy * dy));
        if (ady < r_inner) {
            int xi = (int)isqrt_u32((uint32_t)(r_inner * r_inner - dy * dy));
            if (xo > xi) {
                gfx_fill_rect(fb, cx - xo, cy + dy, xo - xi, 1, px);
                gfx_fill_rect(fb, cx + xi + 1, cy + dy, xo - xi, 1, px);
            }
        } else {
            gfx_fill_rect(fb, cx - xo, cy + dy, 2 * xo + 1, 1, px);
        }
    }
}

void gfx_draw_glyph(const struct gfx_fb *fb, int x, int y, unsigned char ch, int scale, uint32_t fg,
                    uint32_t bg, bool opaque)
{
    if (scale < 1)
        scale = 1;
    const uint8_t *g = font_glyph(ch);
    if (opaque)
        gfx_fill_rect(fb, x, y, GFX_FONT_W * scale, GFX_FONT_H * scale, bg);
    for (int row = 0; row < GFX_FONT_H; row++) {
        uint8_t bits = g[row];
        int col = 0;
        while (col < GFX_FONT_W) {
            if (!(bits & (1u << col))) {
                col++;
                continue;
            }
            int start = col;
            while (col < GFX_FONT_W && (bits & (1u << col)))
                col++;
            gfx_fill_rect(fb, x + start * scale, y + row * scale, (col - start) * scale, scale, fg);
        }
    }
}

void gfx_draw_text_n(const struct gfx_fb *fb, int x, int y, const char *s, size_t max_chars,
                     int scale, uint32_t fg, uint32_t bg, bool opaque)
{
    if (!s)
        return;
    if (scale < 1)
        scale = 1;
    for (size_t i = 0; s[i] && i < max_chars; i++)
        gfx_draw_glyph(fb, x + (int)i * GFX_FONT_W * scale, y, (unsigned char)s[i], scale, fg, bg,
                       opaque);
}

void gfx_draw_text(const struct gfx_fb *fb, int x, int y, const char *s, int scale, uint32_t fg,
                   uint32_t bg, bool opaque)
{
    gfx_draw_text_n(fb, x, y, s, (size_t)-1, scale, fg, bg, opaque);
}

int gfx_text_width(const char *s, int scale)
{
    int n = 0;
    while (s && s[n])
        n++;
    return n * GFX_FONT_W * (scale < 1 ? 1 : scale);
}
