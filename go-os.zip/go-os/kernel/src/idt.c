#include "idt.h"
#include "cpu.h"

static struct idt_entry idt[IDT_ENTRIES] __attribute__((aligned(16)));

void idt_init(void)
{
    /* Use whatever 64-bit code selector the bootloader's GDT provides. */
    uint16_t cs = cpu_read_cs();
    for (unsigned i = 0; i < IDT_EXCEPTION_VECTORS; i++)
        idt[i] = idt_encode_gate(isr_stub_table[i], cs, 0, IDT_GATE_INTERRUPT);

    struct idt_ptr p = { .limit = (uint16_t)(sizeof(idt) - 1), .base = (uint64_t)(uintptr_t)&idt[0] };
    __asm__ volatile("lidt %0" : : "m"(p) : "memory");
}
