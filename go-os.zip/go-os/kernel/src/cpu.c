#include "cpu.h"

static void put32(char *dst, uint32_t v)
{
    for (int i = 0; i < 4; i++)
        dst[i] = (char)(v >> (8 * i));
}

void cpu_vendor(char out[13])
{
    uint32_t a, b, c, d;
    cpuid(0, 0, &a, &b, &c, &d);
    put32(out, b);
    put32(out + 4, d);
    put32(out + 8, c);
    out[12] = '\0';
}

bool cpu_brand(char out[49])
{
    uint32_t a, b, c, d;
    cpuid(0x80000000u, 0, &a, &b, &c, &d);
    if (a < 0x80000004u) {
        out[0] = '\0';
        return false;
    }
    for (uint32_t i = 0; i < 3; i++) {
        cpuid(0x80000002u + i, 0, &a, &b, &c, &d);
        put32(out + 16 * i, a);
        put32(out + 16 * i + 4, b);
        put32(out + 16 * i + 8, c);
        put32(out + 16 * i + 12, d);
    }
    out[48] = '\0';

    size_t start = 0, end = 0;
    while (out[start] == ' ')
        start++;
    while (out[start + end])
        end++;
    while (end > 0 && out[start + end - 1] == ' ')
        end--;
    for (size_t i = 0; i < end; i++)
        out[i] = out[start + i];
    out[end] = '\0';
    return end > 0;
}
