#include "panic.h"
#include "kprintf.h"
#include <stdarg.h>

static void put(struct panic_report *r, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void put(struct panic_report *r, const char *fmt, ...)
{
    if (r->nlines >= PANIC_MAX_LINES)
        return;
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(r->lines[r->nlines++], PANIC_LINE_MAX, fmt, ap);
    va_end(ap);
}

#define U(x) ((unsigned long long)(x))

void panic_build_exception_report(struct panic_report *r, const struct exception_frame *f,
                                  const struct cpu_regs_snapshot *cr)
{
    r->title = "GO.OS KERNEL PANIC";
    r->nlines = 0;
    unsigned v = (unsigned)f->vector;

    put(r, "CPU exception #%u (%s): %s", v, exception_mnemonic(v), exception_name(v));
    if (exception_has_error_code(v)) {
        put(r, "Error code: 0x%016llx", U(f->error_code));
        if (v == 14) {
            put(r, "  %s, %s, %s%s%s",
                (f->error_code & 1) ? "protection violation" : "page not present",
                (f->error_code & 2) ? "write" : "read",
                (f->error_code & 4) ? "user mode" : "supervisor mode",
                (f->error_code & 8) ? ", reserved bit set" : "",
                (f->error_code & 16) ? ", instruction fetch" : "");
            put(r, "Faulting address (CR2): 0x%016llx", U(cr->cr2));
        } else if (v == 10 || v == 11 || v == 12 || v == 13) {
            put(r, "  selector index %llu, %s%s%s", U(f->error_code >> 3),
                (f->error_code & 4) ? "LDT" : ((f->error_code & 2) ? "IDT" : "GDT"),
                (f->error_code & 1) ? ", external event" : "", "");
        }
    }
    put(r, "%s", "");
    put(r, "RIP=0x%016llx  CS=0x%04llx", U(f->rip), U(f->cs));
    put(r, "RSP=0x%016llx  SS=0x%04llx", U(f->rsp), U(f->ss));
    put(r, "RFLAGS=0x%016llx", U(f->rflags));
    put(r, "%s", "");
    put(r, "RAX=0x%016llx  RBX=0x%016llx", U(f->rax), U(f->rbx));
    put(r, "RCX=0x%016llx  RDX=0x%016llx", U(f->rcx), U(f->rdx));
    put(r, "RSI=0x%016llx  RDI=0x%016llx", U(f->rsi), U(f->rdi));
    put(r, "RBP=0x%016llx  R8 =0x%016llx", U(f->rbp), U(f->r8));
    put(r, "R9 =0x%016llx  R10=0x%016llx", U(f->r9), U(f->r10));
    put(r, "R11=0x%016llx  R12=0x%016llx", U(f->r11), U(f->r12));
    put(r, "R13=0x%016llx  R14=0x%016llx", U(f->r13), U(f->r14));
    put(r, "R15=0x%016llx", U(f->r15));
    put(r, "%s", "");
    put(r, "CR0=0x%016llx  CR2=0x%016llx", U(cr->cr0), U(cr->cr2));
    put(r, "CR3=0x%016llx  CR4=0x%016llx", U(cr->cr3), U(cr->cr4));
    put(r, "%s", "");
    put(r, "System halted. Reset or power off the machine.");
}

void panic_render(const struct gfx_fb *fb, const struct panic_report *r)
{
    if (!fb || !fb->base)
        return;
    int w = (int)fb->width, h = (int)fb->height;
    int ts = w >= 2400 ? 3 : (w >= 1100 ? 2 : 1);
    int cell = GFX_FONT_W * ts;
    int line_h = cell + cell / 4;
    int pad = cell;

    gfx_fill_rect(fb, 0, 0, w, h, gfx_pack_rgb(fb, 0x1A0508));
    int banner_h = 3 * cell;
    gfx_fill_rect(fb, 0, 0, w, banner_h, gfx_pack_rgb(fb, 0xB91C1C));
    int tscale = 2 * ts;
    gfx_draw_text(fb, pad, (banner_h - GFX_FONT_H * tscale) / 2, r->title, tscale,
                  gfx_pack_rgb(fb, 0xFFFFFF), 0, false);

    uint32_t amber = gfx_pack_rgb(fb, 0xFDE68A), body = gfx_pack_rgb(fb, 0xF3F4F6);
    int y = banner_h + pad;
    size_t cols = (size_t)((w - 2 * pad) / cell);
    for (unsigned i = 0; i < r->nlines; i++) {
        if (y + cell > h)
            break;
        gfx_draw_text_n(fb, pad, y, r->lines[i], cols, ts, i == 0 ? amber : body, 0, false);
        y += line_h;
    }
}
