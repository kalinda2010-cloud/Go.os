#include "klog.h"
#include "kprintf.h"
#include "serial.h"
#include <stdarg.h>
#include <stdint.h>

#define KLOG_BUF_LINES 48
#define KLOG_LINE_MAX 112

struct entry {
    uint8_t level;
    char text[KLOG_LINE_MAX];
};

static struct entry backlog[KLOG_BUF_LINES];
static unsigned backlog_n;
static klog_sink_fn sink;

const char *klog_level_tag(enum klog_level level)
{
    switch (level) {
    case KLOG_INFO: return "[INFO]";
    case KLOG_OK: return "[ OK ]";
    case KLOG_WARN: return "[WARN]";
    case KLOG_FAIL: return "[FAIL]";
    }
    return "[????]";
}

void klog_reset(void)
{
    backlog_n = 0;
    sink = NULL;
}

void klog_attach_sink(klog_sink_fn fn)
{
    sink = fn;
    if (!fn)
        return;
    for (unsigned i = 0; i < backlog_n; i++)
        fn((enum klog_level)backlog[i].level, backlog[i].text);
    backlog_n = 0;
}

void klog(enum klog_level level, const char *fmt, ...)
{
    char line[KLOG_LINE_MAX];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(line, sizeof line, fmt, ap);
    va_end(ap);

    serial_puts(klog_level_tag(level));
    serial_putc(' ');
    serial_puts(line);
    serial_puts("\r\n");

    if (sink) {
        sink(level, line);
    } else if (backlog_n < KLOG_BUF_LINES) {
        struct entry *e = &backlog[backlog_n++];
        e->level = (uint8_t)level;
        unsigned i = 0;
        for (; line[i] && i < KLOG_LINE_MAX - 1; i++)
            e->text[i] = line[i];
        e->text[i] = '\0';
    }
}
