/*
 * CPU exception entry stubs.
 *
 * The CPU pushes SS,RSP,RFLAGS,CS,RIP (+ an error code for some vectors).
 * Every stub normalises that to "error code + vector number", then jumps to
 * isr_common which saves the GPRs and calls exception_dispatch(frame).
 * Layout must match struct exception_frame in include/exception.h.
 *
 * Alignment: the CPU aligns RSP to 16 before pushing the frame; frame (6 words
 * incl. error code) + vector + 15 GPRs = 22 words = 176 bytes, so RSP is
 * 16-byte aligned again at the `call`, as the SysV ABI requires.
 */
    .section .text

    .macro ISR_NOERR vec
isr_stub_\vec:
    pushq   $0
    pushq   $\vec
    jmp     isr_common
    .endm

    .macro ISR_ERR vec
isr_stub_\vec:
    pushq   $\vec
    jmp     isr_common
    .endm

    .irp vec, 0,1,2,3,4,5,6,7,9,15,16,18,19,20,22,23,24,25,26,27,28,31
    ISR_NOERR \vec
    .endr
    .irp vec, 8,10,11,12,13,14,17,21,29,30
    ISR_ERR \vec
    .endr

isr_common:
    pushq   %rax
    pushq   %rbx
    pushq   %rcx
    pushq   %rdx
    pushq   %rsi
    pushq   %rdi
    pushq   %rbp
    pushq   %r8
    pushq   %r9
    pushq   %r10
    pushq   %r11
    pushq   %r12
    pushq   %r13
    pushq   %r14
    pushq   %r15
    cld
    movq    %rsp, %rdi              /* arg0 = struct exception_frame * */
    call    exception_dispatch
    popq    %r15
    popq    %r14
    popq    %r13
    popq    %r12
    popq    %r11
    popq    %r10
    popq    %r9
    popq    %r8
    popq    %rbp
    popq    %rdi
    popq    %rsi
    popq    %rdx
    popq    %rcx
    popq    %rbx
    popq    %rax
    addq    $16, %rsp               /* drop vector + error code */
    iretq

    .section .rodata
    .balign 8
    .global isr_stub_table
isr_stub_table:
    .irp vec, 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31
    .quad isr_stub_\vec
    .endr

    .section .note.GNU-stack,"",@progbits
