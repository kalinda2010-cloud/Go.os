#include "boot_sequence.h"
#include "cpu.h"
#include "klog.h"
#include "ui.h"
#include "version.h"

static const char *firmware_name(enum boot_firmware fw)
{
    switch (fw) {
    case BOOT_FW_BIOS: return "legacy BIOS";
    case BOOT_FW_EFI32: return "UEFI 32-bit";
    case BOOT_FW_EFI64: return "UEFI 64-bit";
    default: return NULL;
    }
}

void kernel_boot_sequence(const struct boot_info *bi, const struct early_status *early)
{
    /* Missing framebuffer is not an error: we keep booting, headless, on serial. */
    if (bi->fb_valid) {
        ui_attach(&bi->fb);
        klog_attach_sink(ui_log);
    }
    ui_set_progress(5);

    klog(KLOG_INFO, "%s %s starting (Milestone %d)", GOOS_NAME, GOOS_VERSION, GOOS_MILESTONE);

    if (early->serial_ok)
        klog(KLOG_OK, "Serial console ready (COM1)");
    else
        klog(KLOG_INFO, "No serial port detected");
    ui_set_progress(15);

    if (early->idt_ok)
        klog(KLOG_OK, "CPU exceptions ready (IDT, %u vectors)", early->idt_vectors);
    else
        klog(KLOG_FAIL, "CPU exception handling is NOT installed");
    ui_set_progress(30);

    if (bi->base_rev_supported) {
        if (bi->base_rev_loaded_valid)
            klog(KLOG_OK, "Boot protocol: Limine base revision %llu",
                 (unsigned long long)bi->base_rev_loaded);
        else
            klog(KLOG_OK, "Boot protocol: Limine base revision %llu",
                 (unsigned long long)bi->base_rev_requested);
    } else {
        klog(KLOG_WARN, "Loader lacks base revision %llu (compat mode)",
             (unsigned long long)bi->base_rev_requested);
    }

    if (bi->have_loader)
        klog(KLOG_OK, "Bootloader: %s %s", bi->loader_name, bi->loader_version);
    else
        klog(KLOG_WARN, "Bootloader info unavailable");
    ui_set_progress(45);

    const char *fw = firmware_name(bi->firmware);
    if (fw)
        klog(KLOG_OK, "Firmware: %s", fw);
    else
        klog(KLOG_WARN, "Firmware type unknown");

    if (bi->fb_valid)
        klog(KLOG_OK, "Framebuffer: %ux%ux%u", (unsigned)bi->fb.width, (unsigned)bi->fb.height,
             (unsigned)bi->fb.bpp);
    else
        klog(KLOG_WARN, "No usable framebuffer (%s): headless mode, serial log only",
             bi->fb_problem ? bi->fb_problem : "unknown reason");
    ui_set_progress(60);

    if (bi->have_memmap)
        klog(KLOG_OK, "Memory: %llu MiB usable (%u regions)",
             (unsigned long long)(bi->mem_usable_bytes >> 20), (unsigned)bi->memmap_entries);
    else
        klog(KLOG_WARN, "Memory map unavailable");

    if (bi->have_hhdm)
        klog(KLOG_OK, "HHDM offset 0x%016llx", (unsigned long long)bi->hhdm_offset);
    else
        klog(KLOG_WARN, "HHDM offset unavailable");
    ui_set_progress(80);

    char brand[49], vendor[13];
    if (cpu_brand(brand)) {
        klog(KLOG_OK, "CPU: %s", brand);
    } else {
        cpu_vendor(vendor);
        klog(KLOG_OK, "CPU: %s", vendor);
    }
    ui_set_progress(95);

    klog(KLOG_OK, "GO.OS: kernel boot complete");
    ui_set_progress(100);
    klog(KLOG_INFO, "Milestone %d done - system idle (hlt)", GOOS_MILESTONE);
}
