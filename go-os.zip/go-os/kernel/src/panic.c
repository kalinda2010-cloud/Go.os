#include "panic.h"
#include "cpu.h"
#include "kprintf.h"
#include "serial.h"
#include "ui.h"
#include <stdarg.h>

static volatile int panic_depth;
static struct panic_report report; /* static: keeps the 3 KiB off the (possibly damaged) stack */

static void emit(const struct panic_report *r)
{
    serial_puts("\r\n*** ");
    serial_puts(r->title);
    serial_puts(" ***\r\n");
    for (unsigned i = 0; i < r->nlines; i++) {
        serial_puts(r->lines[i]);
        serial_puts("\r\n");
    }
    /* If the framebuffer itself is what faulted we re-enter here and halt (see guard). */
    panic_render(ui_framebuffer(), r);
}

static void enter_panic(void)
{
    __asm__ volatile("cli");
    if (panic_depth++ > 0) {
        serial_puts("\r\n*** nested panic, halting ***\r\n");
        cpu_halt_forever();
    }
}

void panic_exception(const struct exception_frame *f)
{
    enter_panic();
    struct cpu_regs_snapshot cr = { cpu_read_cr0(), cpu_read_cr2(), cpu_read_cr3(), cpu_read_cr4() };
    panic_build_exception_report(&report, f, &cr);
    emit(&report);
    cpu_halt_forever();
}

void kpanic(const char *fmt, ...)
{
    enter_panic();
    report.title = "GO.OS KERNEL PANIC";
    report.nlines = 0;
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(report.lines[report.nlines++], PANIC_LINE_MAX, fmt, ap);
    va_end(ap);
    ksnprintf(report.lines[report.nlines++], PANIC_LINE_MAX, "%s", "");
    ksnprintf(report.lines[report.nlines++], PANIC_LINE_MAX, "System halted.");
    emit(&report);
    cpu_halt_forever();
}
