#include "ui.h"
#include "version.h"

#define LOG_ROWS 13

#define C_BG_TOP     0x070A16u
#define C_BG_BOTTOM  0x1B1141u
#define C_SHADOW     0x03050Cu
#define C_ACCENT     0x2DD4FFu
#define C_ACCENT2    0x8B5CFFu
#define C_TEXT       0xE8ECF8u
#define C_DIM        0x8B95B5u
#define C_PANEL      0x0B1022u
#define C_PANEL_EDGE 0x26325Au
#define C_TRACK      0x1B2548u
#define C_OK         0x4ADE80u
#define C_WARN       0xFACC15u
#define C_FAIL       0xF87171u
#define C_INFO       0x60A5FAu

static struct {
    bool attached;
    struct gfx_fb fb;
    struct ui_layout l;
    unsigned log_row, progress;
    uint32_t panel, track, accent, text, ok, warn, fail, info;
} ui;

static int imin(int a, int b) { return a < b ? a : b; }
static int imax(int a, int b) { return a > b ? a : b; }

/* Lays everything out with the top margin at y = 0; returns the total height. */
static int layout_try(struct ui_layout *l, int w, int ts)
{
    int u = 8 * ts;
    int y = 0;
    l->ts = ts;
    l->cell = u;
    l->line_h = u + u / 4;
    l->log_pad = u / 2;

    y += u;
    l->ring_r = 3 * u;
    l->ring_cx = w / 2;
    l->ring_cy = y + l->ring_r;
    y += 2 * l->ring_r + u;

    l->title_scale = 4 * ts;
    l->title_w = 5 * GFX_FONT_W * l->title_scale;
    l->title_x = (w - l->title_w) / 2;
    l->title_y = y;
    y += GFX_FONT_H * l->title_scale + u / 2;

    l->sub_y = y;
    y += 2 * u;

    l->bar_h = imax(6, u / 2);
    l->bar_w = imax(8 * u, imin(w / 2, 60 * u));
    l->bar_w = imin(l->bar_w, imax(w - 2 * u, 1));
    l->bar_x = (w - l->bar_w) / 2;
    l->bar_y = y;
    y += l->bar_h + u;

    l->log_rows = LOG_ROWS;
    l->log_h = LOG_ROWS * l->line_h + 2 * l->log_pad;
    l->log_w = imax(1, imin(w - 2 * u, 60 * u));
    l->log_x = (w - l->log_w) / 2;
    l->log_y = y;
    l->log_cols = imax(8, (l->log_w - 2 * l->log_pad) / u);
    y += l->log_h + u / 2;

    l->foot_y = y;
    y += u + u / 2;
    return y;
}

void ui_compute_layout(struct ui_layout *l, int w, int h)
{
    int ts_pref = h >= 2000 ? 4 : h >= 1000 ? 3 : h >= 560 ? 2 : 1;
    int ts = ts_pref;
    int total = layout_try(l, w, ts);
    while (ts > 1 && total > h)
        total = layout_try(l, w, --ts);

    int top = (h - total) / 2;
    if (top < 0)
        top = 0;
    l->ring_cy += top;
    l->title_y += top;
    l->sub_y += top;
    l->bar_y += top;
    l->log_y += top;
    l->foot_y += top;
    l->total_h = total;
}

static void draw_title(const struct gfx_fb *fb, const struct ui_layout *l)
{
    static const char title[] = GOOS_NAME; /* "GO.OS" */
    int step = GFX_FONT_W * l->title_scale;
    int sh = imax(2, l->title_scale / 2);
    uint32_t shadow = gfx_pack_rgb(fb, C_SHADOW);
    for (int i = 0; title[i]; i++)
        gfx_draw_glyph(fb, l->title_x + i * step + sh, l->title_y + sh, (unsigned char)title[i],
                       l->title_scale, shadow, 0, false);
    for (int i = 0; title[i]; i++) {
        uint32_t c = title[i] == '.' ? ui.accent : ui.text;
        gfx_draw_glyph(fb, l->title_x + i * step, l->title_y, (unsigned char)title[i],
                       l->title_scale, c, 0, false);
    }
}

static void draw_logo(const struct gfx_fb *fb, const struct ui_layout *l)
{
    int cx = l->ring_cx, cy = l->ring_cy, r = l->ring_r;
    int t = imax(3, l->cell / 4);
    int r2 = r * 2 / 3;
    uint32_t accent2 = gfx_pack_rgb(fb, C_ACCENT2);

    gfx_draw_ring(fb, cx, cy, r, r - t, ui.accent);
    gfx_draw_ring(fb, cx, cy, r2, r2 - t, accent2);
    gfx_fill_circle(fb, cx, cy, imax(3, r / 4), ui.text);
    /* "orbiting" dots; 181/256 ~ cos(45deg) keeps this free of floating point */
    int d1 = (r - t / 2) * 181 / 256;
    gfx_fill_circle(fb, cx + d1, cy - d1, t, ui.text);
    int d2 = (r2 - t / 2) * 181 / 256;
    gfx_fill_circle(fb, cx - d2, cy + d2, imax(2, t * 2 / 3), ui.accent);
}

static void draw_progress(void)
{
    const struct ui_layout *l = &ui.l;
    gfx_fill_rect(&ui.fb, l->bar_x, l->bar_y, l->bar_w, l->bar_h, ui.track);
    int w = (int)((unsigned long long)l->bar_w * ui.progress / 100);
    gfx_fill_rect(&ui.fb, l->bar_x, l->bar_y, w, l->bar_h, ui.accent);
}

static void clear_log_interior(void)
{
    const struct ui_layout *l = &ui.l;
    int bw = l->ts >= 2 ? 2 : 1;
    gfx_fill_rect(&ui.fb, l->log_x + bw, l->log_y + bw, l->log_w - 2 * bw, l->log_h - 2 * bw,
                  ui.panel);
}

void ui_attach(const struct gfx_fb *fb)
{
    if (!fb || !fb->base)
        return;
    ui.fb = *fb;
    const struct gfx_fb *f = &ui.fb;
    ui_compute_layout(&ui.l, (int)f->width, (int)f->height);
    const struct ui_layout *l = &ui.l;

    ui.panel = gfx_pack_rgb(f, C_PANEL);
    ui.track = gfx_pack_rgb(f, C_TRACK);
    ui.accent = gfx_pack_rgb(f, C_ACCENT);
    ui.text = gfx_pack_rgb(f, C_TEXT);
    ui.ok = gfx_pack_rgb(f, C_OK);
    ui.warn = gfx_pack_rgb(f, C_WARN);
    ui.fail = gfx_pack_rgb(f, C_FAIL);
    ui.info = gfx_pack_rgb(f, C_INFO);
    ui.log_row = 0;
    ui.progress = 0;

    gfx_vgradient(f, 0, 0, (int)f->width, (int)f->height, C_BG_TOP, C_BG_BOTTOM);
    draw_logo(f, l);
    draw_title(f, l);

    uint32_t dim = gfx_pack_rgb(f, C_DIM);
    const char *sub = "Kernel Boot - Milestone " "1";
    gfx_draw_text(f, (int)(f->width / 2) - gfx_text_width(sub, l->ts) / 2, l->sub_y, sub, l->ts, dim,
                  0, false);

    draw_progress();

    int bw = l->ts >= 2 ? 2 : 1;
    gfx_fill_rect(f, l->log_x, l->log_y, l->log_w, l->log_h, gfx_pack_rgb(f, C_PANEL_EDGE));
    (void)bw;
    clear_log_interior();

    const char *foot = GOOS_NAME " " GOOS_VERSION " | " GOOS_VENDOR;
    gfx_draw_text(f, (int)(f->width / 2) - gfx_text_width(foot, l->ts) / 2, l->foot_y, foot, l->ts,
                  dim, 0, false);

    ui.attached = true;
}

bool ui_attached(void) { return ui.attached; }
const struct gfx_fb *ui_framebuffer(void) { return ui.attached ? &ui.fb : NULL; }
void ui_reset(void) { ui.attached = false; ui.log_row = 0; ui.progress = 0; }

void ui_set_progress(unsigned percent)
{
    if (!ui.attached)
        return;
    ui.progress = percent > 100 ? 100 : percent;
    draw_progress();
}

void ui_log(enum klog_level level, const char *text)
{
    if (!ui.attached)
        return;
    const struct ui_layout *l = &ui.l;
    if (ui.log_row >= (unsigned)l->log_rows) { /* panel full: start over from the top */
        clear_log_interior();
        ui.log_row = 0;
    }
    uint32_t tagc = level == KLOG_OK ? ui.ok : level == KLOG_WARN ? ui.warn
                  : level == KLOG_FAIL ? ui.fail : ui.info;
    int x = l->log_x + l->log_pad;
    int y = l->log_y + l->log_pad + (int)ui.log_row * l->line_h;
    gfx_draw_text(&ui.fb, x, y, klog_level_tag(level), l->ts, tagc, ui.panel, true);
    gfx_draw_text_n(&ui.fb, x + 7 * l->cell, y, text, (size_t)(l->log_cols - 7), l->ts, ui.text,
                    ui.panel, true);
    ui.log_row++;
}
