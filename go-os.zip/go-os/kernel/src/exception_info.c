#include "exception.h"

static const char *const names[EXC_VECTORS] = {
    "Divide Error", "Debug", "Non-Maskable Interrupt", "Breakpoint", "Overflow",
    "BOUND Range Exceeded", "Invalid Opcode", "Device Not Available", "Double Fault",
    "Coprocessor Segment Overrun", "Invalid TSS", "Segment Not Present", "Stack-Segment Fault",
    "General Protection Fault", "Page Fault", "Reserved", "x87 Floating-Point Exception",
    "Alignment Check", "Machine Check", "SIMD Floating-Point Exception", "Virtualization Exception",
    "Control Protection", "Reserved", "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
    "Hypervisor Injection", "VMM Communication", "Security Exception", "Reserved",
};

static const char *const mnemonics[EXC_VECTORS] = {
    "#DE", "#DB", "NMI", "#BP", "#OF", "#BR", "#UD", "#NM", "#DF", "---", "#TS", "#NP", "#SS", "#GP",
    "#PF", "---", "#MF", "#AC", "#MC", "#XM", "#VE", "#CP", "---", "---", "---", "---", "---", "---",
    "#HV", "#VC", "#SX", "---",
};

const char *exception_name(unsigned v) { return v < EXC_VECTORS ? names[v] : "Unknown"; }
const char *exception_mnemonic(unsigned v) { return v < EXC_VECTORS ? mnemonics[v] : "???"; }

bool exception_has_error_code(unsigned v)
{
    switch (v) {
    case 8: case 10: case 11: case 12: case 13: case 14: case 17: case 21: case 29: case 30:
        return true;
    default:
        return false;
    }
}
