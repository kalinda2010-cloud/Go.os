/*
 * Limine requests. They live in .limine_requests (see linker.ld) between the
 * start/end markers; `used` + `volatile` keep the compiler from dropping them
 * and make every read go to memory, because the bootloader writes the
 * `response` pointers before jumping to the kernel.
 */
#include "boot.h"
#include "version.h"

__attribute__((used, section(".limine_requests_start")))
static volatile uint64_t requests_start_marker[4] = LIMINE_REQUESTS_START_MARKER_INIT;

__attribute__((used, section(".limine_requests")))
static volatile uint64_t base_revision[3] = LIMINE_BASE_REVISION_INIT(GOOS_LIMINE_BASE_REVISION);

__attribute__((used, section(".limine_requests")))
static volatile struct limine_framebuffer_request framebuffer_request = {
    .id = LIMINE_FRAMEBUFFER_REQUEST_ID, .revision = 0, .response = NULL
};

__attribute__((used, section(".limine_requests")))
static volatile struct limine_bootloader_info_request loader_request = {
    .id = LIMINE_BOOTLOADER_INFO_REQUEST_ID, .revision = 0, .response = NULL
};

__attribute__((used, section(".limine_requests")))
static volatile struct limine_firmware_type_request firmware_request = {
    .id = LIMINE_FIRMWARE_TYPE_REQUEST_ID, .revision = 0, .response = NULL
};

__attribute__((used, section(".limine_requests")))
static volatile struct limine_hhdm_request hhdm_request = {
    .id = LIMINE_HHDM_REQUEST_ID, .revision = 0, .response = NULL
};

__attribute__((used, section(".limine_requests")))
static volatile struct limine_memmap_request memmap_request = {
    .id = LIMINE_MEMMAP_REQUEST_ID, .revision = 0, .response = NULL
};

__attribute__((used, section(".limine_requests_end")))
static volatile uint64_t requests_end_marker[2] = LIMINE_REQUESTS_END_MARKER_INIT;

void boot_collect(struct boot_info *bi)
{
    struct boot_raw raw;
    raw.base_rev_requested = GOOS_LIMINE_BASE_REVISION;
    raw.base_rev[0] = base_revision[0];
    raw.base_rev[1] = base_revision[1];
    raw.base_rev[2] = base_revision[2];
    raw.framebuffer = framebuffer_request.response;
    raw.hhdm = hhdm_request.response;
    raw.memmap = memmap_request.response;
    raw.loader = loader_request.response;
    raw.firmware = firmware_request.response;
    boot_parse(bi, &raw);
}
