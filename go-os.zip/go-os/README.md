# GO.OS - Milestone 1: Kernel Boot

A freestanding x86_64 kernel in C, booted by **Limine**, with a framebuffer boot
screen, a boot-status log, safe handling of a missing framebuffer and basic CPU
exception handling. No Linux, no HTML/browser simulation.

## What the kernel does

1. Limine loads `go-os.elf` (higher-half ELF64) and jumps to `_start` (`entry.S`), which switches to the kernel's own 64 KiB stack and calls `kmain`.
2. COM1 serial is probed (loopback test; silently disabled if no UART).
3. An IDT with 32 exception gates is installed (`isr.S`, `idt.c`). Any exception except `#BP` ends in a **kernel panic screen** (vector, error code, RIP/RSP/CS/SS/RFLAGS, all GPRs, CR0/2/3/4, page-fault decoding) shown on the framebuffer and on serial; the CPU then halts.
4. Limine's answers are validated (`boot_parse.c`). **If there is no usable framebuffer** (no response, zero framebuffers, NULL address, bad size/bpp/pitch/masks) the kernel does not crash: it logs the reason on serial and continues headless.
5. Otherwise the GO.OS boot screen is drawn (gradient, logo, title, progress bar, status panel) and every boot step is logged: base revision, bootloader, firmware (UEFI/BIOS), framebuffer, memory, HHDM, CPU.
6. It prints `GO.OS: kernel boot complete` (used by the automated boot test) and idles in `hlt`.

Supported framebuffer formats: 32/24/16/15 bpp RGB with any mask layout and any pitch.

## Layout

```
Makefile  limine.conf  README.md
kernel/linker.ld              higher-half layout, R / RX / R / RW segments
kernel/include/  kernel/src/  entry.S isr.S main.c boot*.c gfx.c ui.c panic*.c idt.c ...
tools/verify_kernel.py        static ELF + Limine-request checks
tools/check_protocol.py       compare protocol constants with an official limine.h
tools/ppm2png.py              PPM -> PNG helper
tests/                        host unit tests (printf, IDT, real ISR stubs, rendering)
.github/workflows/build-iso.yml   CI that builds the ISO and boots it in QEMU
```

`kernel/include/limine_proto.h` is a minimal, hand-written subset of the Limine
protocol (magic numbers + struct layouts). Run `make check-protocol` after
fetching Limine to compare the constants with the official header.

## Build

Needs: `gcc`, `ld` (binutils), `make`, `python3`; for the ISO also `xorriso` and `git` (to fetch Limine); for testing `qemu-system-x86_64` and OVMF.

Ubuntu/Debian:
```sh
sudo apt install build-essential xorriso git python3 qemu-system-x86 ovmf
make            # kernel only        -> build/go-os.elf
make check      # static checks
make test       # host tests + preview PNGs in build/preview/
make iso        # fetches Limine (branch v9.x-binary), builds go-os.iso
```
macOS (Homebrew): `brew install x86_64-elf-gcc xorriso qemu git` then `make iso CROSS_COMPILE=x86_64-elf-`.
Windows: use WSL2 (Ubuntu) and follow the Ubuntu steps.
No local toolchain: push the folder to GitHub; the included workflow builds the ISO and uploads it as an artifact.

Limine options: `LIMINE_BRANCH=v10.x-binary` to pick another release line; `LIMINE_DIR=/usr/share/limine LIMINE_BIN=/usr/bin/limine` to use a distro package instead of cloning. Files needed in `LIMINE_DIR`: `BOOTX64.EFI limine-bios.sys limine-bios-cd.bin limine-uefi-cd.bin`.

Exception self-test: `make clean && make iso TEST_FAULT=pf` (also `div0 ud2 gp bp`). `bp` logs and continues; the others must end in the panic screen.

## Test in QEMU
```sh
make run          # UEFI (OVMF); kernel log also appears in this terminal via serial
make run-bios     # legacy BIOS
make test-boot    # headless; passes if the serial log contains the boot marker
```
If OVMF is not found: `make run OVMF=/path/to/OVMF.fd`.

## Install in UTM SE (iPhone/iPad) or UTM (Mac)
1. Copy `go-os.iso` to the device (Files / AirDrop / iCloud Drive).
2. UTM: **Create a New Virtual Machine -> Emulate -> Other**.
3. Boot Device: **CD/DVD Image**, then pick `go-os.iso`.
4. Hardware: Architecture **x86_64**, System **Standard PC (Q35)**, Memory **256 MiB**, CPU Cores **4**.
5. Storage: keep the default or skip. Save.
6. Edit the VM -> **QEMU** tab -> enable **UEFI Boot**.
7. Start. UTM SE has no JIT, so UEFI + Limine take a while to appear: be patient. Limine counts down 3 s, then GO.OS boots.
8. Black screen? Edit -> Display -> try emulated card `virtio-ramfb` or `VGA`.

## Real hardware
`sudo dd if=go-os.iso of=/dev/sdX bs=4M conv=fsync status=progress` (double-check the device!). Disable Secure Boot (Limine is unsigned). Test in a VM first; use at your own risk.

## Known limits (by design, per roadmap)
- Relies on Limine's GDT; no TSS/IST yet, so a double fault caused by a broken stack triple-faults. Own GDT/IDT/TSS come with the next milestone.
- Interrupts stay disabled (no PIC/APIC, no keyboard/mouse yet).
- Log panel wraps to the top when full.

## Roadmap
GDT/IDT + TSS -> memory management -> keyboard/mouse -> filesystem -> processes -> multitasking -> graphical desktop -> built-in apps.
