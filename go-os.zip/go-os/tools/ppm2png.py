#!/usr/bin/env python3
"""Convert binary PPM (P6) files to PNG using only the standard library."""
import struct
import sys
import zlib


def convert(src):
    with open(src, "rb") as f:
        assert f.readline().strip() == b"P6"
        w, h = map(int, f.readline().split())
        f.readline()  # maxval
        raw = f.read(w * h * 3)
    rows = b"".join(b"\x00" + raw[y * w * 3:(y + 1) * w * 3] for y in range(h))

    def chunk(tag, body):
        c = struct.pack(">I", len(body)) + tag + body
        return c + struct.pack(">I", zlib.crc32(tag + body) & 0xFFFFFFFF)

    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(rows, 9)) + chunk(b"IEND", b""))
    dst = src[:-4] + ".png"
    with open(dst, "wb") as f:
        f.write(png)
    print("wrote", dst)


for p in sys.argv[1:]:
    convert(p)
