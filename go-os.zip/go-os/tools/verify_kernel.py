#!/usr/bin/env python3
"""Static sanity checks for the GO.OS kernel ELF (no emulator needed).

Checks the ELF layout Limine requires and that the Limine request area in the
image contains the expected markers, base-revision tag and request IDs.
NOTE: the expected magic numbers below are the same transcription used by
kernel/include/limine_proto.h; use `make check-protocol` to compare them
against an official limine.h.
"""
import struct
import sys

KERNEL_BASE = 0xFFFFFFFF80000000
PAGE = 0x1000
COMMON = (0xC7B1DD30DF4C8B88, 0x0A82E883A194F07B)
BASE_REV_MAGIC = (0xF9562B2D5C95A6C8, 0x6A7B384944536BDC)
START_MARKER = (0xF6B8F4B39DE7D1AE, 0xFAB91A6940FCB9CF, 0x785C6ED015D3E316, 0x181E920A7852B9D9)
END_MARKER = (0xADC0E0531BB10D03, 0x9572709F31764C62)
REQUESTS = {
    "framebuffer": (0x9D5827DCD881DD75, 0xA3148604F6FAB11B),
    "bootloader-info": (0xF55038D8E2A1202F, 0x279426FCF5F59740),
    "firmware-type": (0x8C2F75D90BEF28A8, 0x7045A4688EAC00C3),
    "hhdm": (0x48DCF1CB8AD2B852, 0x63984E959A98244B),
    "memory-map": (0x67CF3D9D378A806F, 0xE304ACDFC50C3C62),
}
WANT_BASE_REVISION = 3

failures = 0


def check(ok, msg):
    global failures
    print(("PASS  " if ok else "FAIL  ") + msg)
    if not ok:
        failures += 1


def main(path):
    data = open(path, "rb").read()
    check(data[:4] == b"\x7fELF" and data[4] == 2 and data[5] == 1, "ELF64, little-endian")
    (e_type, e_machine, _v, e_entry, e_phoff, e_shoff, _fl, _eh, e_phentsize, e_phnum,
     e_shentsize, e_shnum, e_shstrndx) = struct.unpack_from("<HHIQQQIHHHHHH", data, 16)
    check(e_type == 2, "ET_EXEC (static, non-PIE)")
    check(e_machine == 62, "machine is x86-64")
    check(e_entry >= KERNEL_BASE, "entry point 0x%x is in the higher half" % e_entry)

    phdrs = []
    for i in range(e_phnum):
        phdrs.append(struct.unpack_from("<IIQQQQQQ", data, e_phoff + i * e_phentsize))
    loads = [p for p in phdrs if p[0] == 1]
    check(len(loads) >= 1, "%d PT_LOAD segment(s)" % len(loads))
    check(not any(p[0] in (3, 2) for p in phdrs), "no PT_INTERP / PT_DYNAMIC")
    entry_ok = False
    for (_t, flags, off, vaddr, _pa, filesz, memsz, _al) in loads:
        tag = "%s%s%s" % ("R" if flags & 4 else "-", "W" if flags & 2 else "-", "X" if flags & 1 else "-")
        good = (vaddr >= KERNEL_BASE and vaddr % PAGE == 0 and off % PAGE == vaddr % PAGE
                and memsz >= filesz and not (flags & 2 and flags & 1))
        check(good, "segment %s vaddr=0x%x filesz=0x%x memsz=0x%x (page-aligned, no W+X)"
              % (tag, vaddr, filesz, memsz))
        if flags & 1 and vaddr <= e_entry < vaddr + memsz:
            entry_ok = True
    check(entry_ok, "entry point lies inside an executable segment")

    shdrs = [struct.unpack_from("<IIQQQQIIQQ", data, e_shoff + i * e_shentsize) for i in range(e_shnum)]
    stroff = shdrs[e_shstrndx][4]

    def name_of(sh):
        end = data.index(b"\0", stroff + sh[0])
        return data[stroff + sh[0]:end].decode()

    secs = {name_of(s): s for s in shdrs}
    check(not any(n in secs for n in (".interp", ".dynamic", ".rela.dyn", ".rela.plt")),
          "no dynamic-linking sections")

    # undefined symbols
    undefined = []
    for s in shdrs:
        if s[1] == 2:  # SHT_SYMTAB
            strtab = shdrs[s[6]]
            for i in range(1, s[5] // 24):
                st_name, _info, _o, st_shndx, _v, _sz = struct.unpack_from("<IBBHQQ", data, s[4] + i * 24)
                if st_shndx == 0:
                    end = data.index(b"\0", strtab[4] + st_name)
                    undefined.append(data[strtab[4] + st_name:end].decode())
    check(not undefined, "no undefined symbols %s" % (undefined or ""))

    req = secs.get(".limine_requests")
    check(req is not None, ".limine_requests section present")
    if req is None:
        return
    addr, off, size = req[3], req[4], req[5]
    blob = data[off:off + size]
    q = lambda o: struct.unpack_from("<Q", blob, o)[0]
    check(addr % 8 == 0, "request area 8-byte aligned (0x%x)" % addr)
    check(tuple(q(i * 8) for i in range(4)) == START_MARKER, "start marker is first in the request area")

    # trailing bytes may be padding: the end marker is the last non-zero 16 bytes
    end_off = None
    for o in range(0, size - 15, 8):
        if (q(o), q(o + 8)) == END_MARKER:
            end_off = o
    check(end_off is not None, "end marker present")
    if end_off is not None:
        check(not any(blob[end_off + 16:]), "end marker is last (only padding after it)")

    base_off = None
    for o in range(32, size - 23, 8):
        if (q(o), q(o + 8)) == BASE_REV_MAGIC:
            base_off = o
    check(base_off is not None, "base revision tag present")
    if base_off is not None:
        check(q(base_off + 16) == WANT_BASE_REVISION, "base revision requested = %d" % WANT_BASE_REVISION)

    for name, (a, b) in REQUESTS.items():
        found = None
        for o in range(32, size - 47, 8):
            if (q(o), q(o + 8), q(o + 16), q(o + 24)) == (COMMON[0], COMMON[1], a, b):
                found = o
        check(found is not None and (end_off is None or found < end_off), "%s request inside markers" % name)
        if found is not None:
            check(q(found + 32) == 0 and q(found + 40) == 0,
                  "%s request: revision 0, response pointer 0 (for Limine to fill)" % name)

    print()
    print("RESULT: %s (%d failure%s)" % ("ALL CHECKS PASSED" if not failures else "FAILED",
                                          failures, "" if failures == 1 else "s"))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("usage: verify_kernel.py build/go-os.elf")
    main(sys.argv[1])
    sys.exit(1 if failures else 0)
