#!/usr/bin/env python3
"""Compare the Limine magic numbers used by GO.OS with an official limine.h.

usage: check_protocol.py path/to/limine.h
Every expected number pair must appear inside one #define of the header.
"""
import re
import sys

EXPECT = {
    "common magic": (0xC7B1DD30DF4C8B88, 0x0A82E883A194F07B),
    "base revision tag": (0xF9562B2D5C95A6C8, 0x6A7B384944536BDC),
    "requests start marker (words 0-1)": (0xF6B8F4B39DE7D1AE, 0xFAB91A6940FCB9CF),
    "requests start marker (words 2-3)": (0x785C6ED015D3E316, 0x181E920A7852B9D9),
    "requests end marker": (0xADC0E0531BB10D03, 0x9572709F31764C62),
    "framebuffer request": (0x9D5827DCD881DD75, 0xA3148604F6FAB11B),
    "bootloader info request": (0xF55038D8E2A1202F, 0x279426FCF5F59740),
    "firmware type request": (0x8C2F75D90BEF28A8, 0x7045A4688EAC00C3),
    "HHDM request": (0x48DCF1CB8AD2B852, 0x63984E959A98244B),
    "memory map request": (0x67CF3D9D378A806F, 0xE304ACDFC50C3C62),
}

if len(sys.argv) != 2 or not sys.argv[1]:
    print("SKIP: no limine.h found (the binary branch may not ship one). "
          "Pass an official limine.h to verify the protocol constants.")
    sys.exit(0)

text = open(sys.argv[1], errors="replace").read().replace("\\\n", " ")
defines = [m.group(0).lower() for m in re.finditer(r"#define[^\n]*", text)]
bad = 0
for name, (a, b) in EXPECT.items():
    ha, hb = "0x%016x" % a, "0x%016x" % b
    # the header may print the numbers without zero padding
    pats = [(ha, hb), (hex(a), hex(b))]
    ok = any(any(x in d and y in d for d in defines) for x, y in pats)
    print(("OK    " if ok else "DIFF  ") + name)
    bad += 0 if ok else 1
print("RESULT:", "all constants match" if not bad else "%d constant(s) differ - fix limine_proto.h" % bad)
sys.exit(1 if bad else 0)
