/* Host replacements for the hardware-facing serial port. Output is captured. */
#include "serial.h"
#include <string.h>

static char transcript[1 << 16];
static size_t n;

void serial_init(void) {}
bool serial_present(void) { return true; }
void serial_putc(char c)
{
    if (n + 1 < sizeof transcript) {
        transcript[n++] = c;
        transcript[n] = 0;
    }
}
void serial_puts(const char *s) { while (s && *s) serial_putc(*s++); }

const char *host_serial_transcript(void) { return transcript; }
void host_serial_reset(void) { n = 0; transcript[0] = 0; }
