#ifndef TEST_COMMON_H
#define TEST_COMMON_H
#include <stdio.h>
static int t_fail, t_total;
#define CHECK(cond)                                                                  \
    do {                                                                             \
        t_total++;                                                                   \
        if (!(cond)) {                                                               \
            t_fail++;                                                                \
            printf("  FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);                 \
        }                                                                            \
    } while (0)
#define TEST_DONE(name)                                                              \
    do {                                                                             \
        printf("%s: %d/%d checks passed\n", name, t_total - t_fail, t_total);        \
        return t_fail ? 1 : 0;                                                       \
    } while (0)
#endif
