/*
 * Runs the REAL kernel/src/isr.S stubs for all 32 vectors in user space and
 * checks frame layout, error-code handling, 16-byte alignment, register
 * save/restore and that handler edits to the frame survive the iretq path.
 */
#include "exception.h"
#include "idt.h"
#include "test_common.h"
#include <stdint.h>
#include <string.h>

extern void isr_harness_run(void *stub, uint64_t has_err, uint64_t errcode, const uint64_t in[15],
                            uint64_t out[15]);
extern char isr_harness_resume[];

static struct exception_frame captured;
static int calls, align_ok;

void exception_dispatch(struct exception_frame *f)
{
    captured = *f;
    align_ok = (((uintptr_t)f) & 0xF) == 0;
    f->rax += 1; /* handler-side modification must reach the restored registers */
    calls++;
}

int main(void)
{
    uint16_t cs, ss;
    __asm__ volatile("mov %%cs, %0" : "=r"(cs));
    __asm__ volatile("mov %%ss, %0" : "=r"(ss));

    for (unsigned v = 0; v < IDT_EXCEPTION_VECTORS; v++) {
        uint64_t in[15], out[15];
        for (int i = 0; i < 15; i++)
            in[i] = 0x0123456789abcdefULL * (uint64_t)(i + 3) + ((uint64_t)v << 48) + (uint64_t)i;
        bool has_err = exception_has_error_code(v);
        uint64_t errcode = 0xE000u + v;

        calls = 0;
        align_ok = 0;
        memset(&captured, 0xAA, sizeof captured);
        isr_harness_run((void *)(uintptr_t)isr_stub_table[v], has_err, errcode, in, out);

        CHECK(calls == 1);
        CHECK(align_ok);
        CHECK(captured.vector == v);
        CHECK(captured.error_code == (has_err ? errcode : 0));
        CHECK(captured.rip == (uint64_t)(uintptr_t)isr_harness_resume);
        CHECK(captured.cs == cs && captured.ss == ss);
        CHECK((captured.rsp & 0xF) == 0 && captured.rsp != 0);
        const uint64_t seen[15] = { captured.rax, captured.rbx, captured.rcx, captured.rdx,
                                    captured.rsi, captured.rdi, captured.rbp, captured.r8,
                                    captured.r9,  captured.r10, captured.r11, captured.r12,
                                    captured.r13, captured.r14, captured.r15 };
        for (int i = 0; i < 15; i++) {
            CHECK(seen[i] == in[i]);                            /* frame order matches struct */
            CHECK(out[i] == in[i] + (i == 0 ? 1u : 0u));        /* restored; rax edited */
        }
    }
    TEST_DONE("test_isr");
}
