#include "idt.h"
#include "test_common.h"
#include <string.h>

int main(void)
{
    struct idt_entry e = idt_encode_gate(0xffffffff80123456ULL, 0x28, 1, IDT_GATE_INTERRUPT);
    CHECK(sizeof e == 16);
    CHECK(e.offset_lo == 0x3456 && e.offset_mid == 0x8012 && e.offset_hi == 0xffffffffu);
    CHECK(e.selector == 0x28 && e.ist == 1 && e.type_attr == 0x8E && e.zero == 0);
    uint64_t off = e.offset_lo | ((uint64_t)e.offset_mid << 16) | ((uint64_t)e.offset_hi << 32);
    CHECK(off == 0xffffffff80123456ULL);
    static const uint8_t want[16] = { 0x56, 0x34, 0x28, 0x00, 0x01, 0x8E, 0x12, 0x80,
                                      0xff, 0xff, 0xff, 0xff, 0, 0, 0, 0 };
    CHECK(memcmp(&e, want, 16) == 0); /* exact bytes the CPU will read */
    CHECK(idt_encode_gate(0, 0, 9, 0).ist == 1); /* IST is masked to 3 bits */
    TEST_DONE("test_idt");
}
