/*
 * Renders the real boot UI, boot sequence and panic screen into fake
 * framebuffers of several formats, checks the "no framebuffer" paths, and
 * writes PPM images (convert with tools/ppm2png.py) for visual inspection.
 * These are HOST renderings of the kernel's own drawing code - not VM screenshots.
 */
#include "boot.h"
#include "boot_sequence.h"
#include "exception.h"
#include "font.h"
#include "gfx.h"
#include "klog.h"
#include "panic.h"
#include "test_common.h"
#include "ui.h"
#include <stdlib.h>
#include <string.h>

extern const char *host_serial_transcript(void);
extern void host_serial_reset(void);

static const char *outdir = ".";

struct fmt { const char *name; uint32_t bpp; uint8_t masks[6]; };
static const struct fmt BGRX = { "bgrx", 32, { 8, 16, 8, 8, 8, 0 } };
static const struct fmt RGBX = { "rgbx", 32, { 8, 0, 8, 8, 8, 16 } };
static const struct fmt RGB24 = { "rgb24", 24, { 8, 16, 8, 8, 8, 0 } };
static const struct fmt RGB565 = { "rgb565", 16, { 5, 11, 6, 5, 5, 0 } };

static uint8_t *make_fb(struct gfx_fb *fb, uint32_t w, uint32_t h, const struct fmt *f, uint32_t extra_pitch)
{
    uint32_t pitch = w * ((f->bpp + 7) / 8) + extra_pitch;
    uint8_t *mem = calloc(pitch, h);
    enum gfx_fb_status st = gfx_fb_setup(fb, mem, w, h, pitch, f->bpp, 1, f->masks);
    CHECK(st == GFX_FB_OK);
    return mem;
}

static void write_ppm(const struct gfx_fb *fb, const char *name)
{
    char path[512];
    snprintf(path, sizeof path, "%s/%s.ppm", outdir, name);
    FILE *fp = fopen(path, "wb");
    if (!fp) { printf("  cannot write %s\n", path); t_fail++; return; }
    fprintf(fp, "P6\n%u %u\n255\n", fb->width, fb->height);
    for (uint32_t y = 0; y < fb->height; y++) {
        for (uint32_t x = 0; x < fb->width; x++) {
            const uint8_t *p = fb->base + (size_t)y * fb->pitch + (size_t)x * fb->bytes_pp;
            uint32_t v = 0;
            for (int i = fb->bytes_pp - 1; i >= 0; i--) v = (v << 8) | p[i];
            uint32_t r = (v >> fb->r_shift) & ((1u << fb->r_size) - 1);
            uint32_t g = (v >> fb->g_shift) & ((1u << fb->g_size) - 1);
            uint32_t b = (v >> fb->b_shift) & ((1u << fb->b_size) - 1);
            unsigned char rgb[3] = { (unsigned char)(r * 255 / ((1u << fb->r_size) - 1)),
                                     (unsigned char)(g * 255 / ((1u << fb->g_size) - 1)),
                                     (unsigned char)(b * 255 / ((1u << fb->b_size) - 1)) };
            fwrite(rgb, 1, 3, fp);
        }
    }
    fclose(fp);
}

static uint32_t rgb_at(const struct gfx_fb *fb, int x, int y)
{
    const uint8_t *p = fb->base + (size_t)y * fb->pitch + (size_t)x * fb->bytes_pp;
    uint32_t v = 0;
    for (int i = fb->bytes_pp - 1; i >= 0; i--) v = (v << 8) | p[i];
    return v;
}

static void fake_info(struct boot_info *bi, struct gfx_fb *fb)
{
    memset(bi, 0, sizeof *bi);
    bi->base_rev_supported = true;
    bi->base_rev_requested = 3;
    bi->base_rev_loaded_valid = true;
    bi->base_rev_loaded = 3;
    if (fb) { bi->fb_valid = true; bi->fb = *fb; }
    else bi->fb_problem = "bootloader gave no framebuffer response";
    bi->have_loader = true;
    strcpy(bi->loader_name, "Limine");
    strcpy(bi->loader_version, "9.2.3");
    bi->firmware = BOOT_FW_EFI64;
    bi->have_hhdm = true;
    bi->hhdm_offset = 0xffff800000000000ULL;
    bi->have_memmap = true;
    bi->memmap_entries = 12;
    bi->mem_usable_bytes = 245ULL << 20;
}

static void scenario(const char *name, uint32_t w, uint32_t h, const struct fmt *f, uint32_t extra_pitch)
{
    struct gfx_fb fb;
    uint8_t *mem = make_fb(&fb, w, h, f, extra_pitch);
    struct boot_info bi;
    fake_info(&bi, &fb);
    struct early_status early = { true, true, 32 };

    klog_reset(); ui_reset(); host_serial_reset();
    kernel_boot_sequence(&bi, &early);

    CHECK(ui_attached());
    CHECK(strstr(host_serial_transcript(), "GO.OS: kernel boot complete") != NULL);
    uint32_t top = rgb_at(&fb, 0, 0), bottom = rgb_at(&fb, 0, (int)h - 1);
    CHECK(top != bottom);                          /* gradient was painted */
    write_ppm(&fb, name);
    printf("  rendered %s (%ux%u %s, pitch %u)\n", name, w, h, f->name, fb.pitch);
    free(mem);
}

static void layout_sweep(void)
{
    static const int sizes[][2] = { { 640, 480 }, { 800, 600 }, { 1024, 768 }, { 1280, 720 },
                                    { 1280, 800 }, { 1366, 768 }, { 1920, 1080 }, { 2560, 1440 },
                                    { 3840, 2160 }, { 480, 800 } };
    for (unsigned i = 0; i < sizeof sizes / sizeof sizes[0]; i++) {
        int w = sizes[i][0], h = sizes[i][1];
        struct ui_layout l;
        ui_compute_layout(&l, w, h);
        int ok = l.ring_cy - l.ring_r >= 0 && l.foot_y + l.cell <= h && l.log_y + l.log_h <= h
              && l.bar_x >= 0 && l.bar_x + l.bar_w <= w && l.log_x >= 0 && l.log_x + l.log_w <= w
              && l.title_x >= 0 && l.title_x + l.title_w <= w && l.log_cols >= 20;
        if (!ok) printf("  layout %dx%d out of bounds (ts=%d total=%d)\n", w, h, l.ts, l.total_h);
        CHECK(ok);
    }
}

static void missing_framebuffer(void)
{
    /* 1) end-to-end: kernel_boot_sequence with no framebuffer must not crash and must say so on serial */
    struct boot_info bi;
    fake_info(&bi, NULL);
    struct early_status early = { true, true, 32 };
    klog_reset(); ui_reset(); host_serial_reset();
    kernel_boot_sequence(&bi, &early);
    CHECK(!ui_attached());
    CHECK(ui_framebuffer() == NULL);
    CHECK(strstr(host_serial_transcript(), "headless mode") != NULL);
    CHECK(strstr(host_serial_transcript(), "GO.OS: kernel boot complete") != NULL);
    ui_log(KLOG_OK, "ignored");        /* all UI calls are safe no-ops when detached */
    ui_set_progress(50);
    panic_render(NULL, &(struct panic_report){ 0 });

    /* 2) boot_parse: every way the bootloader can fail to deliver a framebuffer */
    struct boot_raw raw;
    memset(&raw, 0, sizeof raw);
    raw.base_rev[1] = LIMINE_BASE_REVISION_MAGIC_1;
    raw.base_rev[2] = 3;                                   /* loader did not accept our revision */
    boot_parse(&bi, &raw);
    CHECK(!bi.fb_valid && bi.fb_problem && !bi.base_rev_supported && !bi.have_memmap && !bi.have_loader);

    struct limine_framebuffer_response resp = { 0, 0, NULL };
    raw.framebuffer = &resp;
    boot_parse(&bi, &raw); CHECK(!bi.fb_valid);            /* count == 0 */
    struct limine_framebuffer *none[1] = { NULL };
    resp.framebuffer_count = 1; resp.framebuffers = none;
    boot_parse(&bi, &raw); CHECK(!bi.fb_valid);            /* NULL descriptor */

    uint8_t pixel[64 * 4 * 64];
    struct limine_framebuffer f;
    memset(&f, 0, sizeof f);
    f.address = pixel; f.width = 64; f.height = 64; f.pitch = 256; f.bpp = 32;
    f.memory_model = 1; f.red_mask_size = 8; f.red_mask_shift = 16; f.green_mask_size = 8;
    f.green_mask_shift = 8; f.blue_mask_size = 8; f.blue_mask_shift = 0;
    struct limine_framebuffer *one[1] = { &f };
    resp.framebuffers = one;
    boot_parse(&bi, &raw); CHECK(bi.fb_valid && bi.fb.width == 64);   /* good case */

    f.address = NULL;            boot_parse(&bi, &raw); CHECK(!bi.fb_valid); f.address = pixel;
    f.width = 0;                 boot_parse(&bi, &raw); CHECK(!bi.fb_valid); f.width = 64;
    f.bpp = 8;                   boot_parse(&bi, &raw); CHECK(!bi.fb_valid); f.bpp = 32;
    f.memory_model = 0;          boot_parse(&bi, &raw); CHECK(!bi.fb_valid); f.memory_model = 1;
    f.pitch = 100;               boot_parse(&bi, &raw); CHECK(!bi.fb_valid); f.pitch = 256;
    f.red_mask_size = 0;         boot_parse(&bi, &raw); CHECK(!bi.fb_valid); f.red_mask_size = 8;
    f.red_mask_shift = 30;       boot_parse(&bi, &raw); CHECK(!bi.fb_valid); f.red_mask_shift = 16;
    boot_parse(&bi, &raw);       CHECK(bi.fb_valid);               /* restored */

    /* zeroed masks on a plain 32-bit mode fall back to XRGB8888 */
    f.red_mask_size = f.green_mask_size = f.blue_mask_size = 0;
    boot_parse(&bi, &raw);       CHECK(bi.fb_valid && bi.fb.r_shift == 16 && bi.fb.b_shift == 0);

    /* memory map, loader strings, firmware */
    struct limine_memmap_entry e0 = { 0x1000, 0x100000, LIMINE_MEMMAP_USABLE };
    struct limine_memmap_entry e1 = { 0xfee00000, 0x1000, LIMINE_MEMMAP_RESERVED };
    struct limine_memmap_entry e2 = { 0x200000, 0x300000, LIMINE_MEMMAP_BOOTLOADER_RECLAIMABLE };
    struct limine_memmap_entry *ents[4] = { &e0, &e1, NULL, &e2 };
    struct limine_memmap_response mm = { 0, 4, ents };
    struct limine_bootloader_info_response lo = { 0, "Limine", "9.9.9-a-very-long-version-string-exceeding-buffer" };
    struct limine_firmware_type_response fw = { 0, LIMINE_FIRMWARE_TYPE_X86BIOS };
    raw.memmap = &mm; raw.loader = &lo; raw.firmware = &fw;
    boot_parse(&bi, &raw);
    CHECK(bi.have_memmap && bi.memmap_entries == 3 && bi.mem_usable_bytes == 0x100000 + 0x300000);
    CHECK(bi.have_loader && strlen(bi.loader_version) == sizeof bi.loader_version - 1);
    CHECK(bi.firmware == BOOT_FW_BIOS);
    struct limine_memmap_response mm2 = { 0, 5, NULL };    /* entries == NULL must not be dereferenced */
    raw.memmap = &mm2;
    boot_parse(&bi, &raw); CHECK(!bi.have_memmap);
}

static void font_sheet(void)
{
    struct gfx_fb fb;
    uint8_t *mem = make_fb(&fb, 800, 330, &BGRX, 0);
    gfx_fill_rect(&fb, 0, 0, 800, 330, gfx_pack_rgb(&fb, 0x10162C));
    uint32_t fg = gfx_pack_rgb(&fb, 0xE8ECF8), bg = gfx_pack_rgb(&fb, 0x10162C);
    for (int i = 0; i < 95; i++)
        gfx_draw_glyph(&fb, 16 + (i % 32) * 24, 16 + (i / 32) * 40, (unsigned char)(0x20 + i), 3, fg, bg, true);
    gfx_draw_text(&fb, 16, 150, "The quick brown fox jumps over the lazy dog 0123456789", 2, fg, bg, true);
    gfx_draw_text(&fb, 16, 180, "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG", 2, fg, bg, true);
    gfx_draw_text(&fb, 16, 215, "GO.OS [ OK ] [WARN] [FAIL] 0x%016llx ~ | { } @ # $ & * ( ) _ + = ? / \\ < > ;", 1, fg, bg, true);
    write_ppm(&fb, "font_sheet");
    free(mem);
}

static void panic_screen(void)
{
    struct gfx_fb fb;
    uint8_t *mem = make_fb(&fb, 1280, 800, &BGRX, 0);
    struct exception_frame f;
    memset(&f, 0, sizeof f);
    f.vector = 14; f.error_code = 0x2; f.rip = 0xffffffff80002f10ULL; f.cs = 0x28;
    f.rflags = 0x10006; f.rsp = 0xffff800000123f80ULL; f.ss = 0x30;
    f.rax = 0x1122334455667788ULL; f.rbx = 0xdeadbeef; f.r15 = 0xffffffff80005000ULL;
    struct cpu_regs_snapshot cr = { 0x80010033, 0xdeadb000, 0x1a2b3000, 0x20 };
    struct panic_report r;
    panic_build_exception_report(&r, &f, &cr);
    CHECK(r.nlines > 10 && strstr(r.lines[0], "#14 (#PF): Page Fault"));
    CHECK(strstr(r.lines[1], "0x0000000000000002") != NULL);
    CHECK(strstr(r.lines[2], "write") && strstr(r.lines[2], "page not present"));
    CHECK(strstr(r.lines[3], "0x00000000deadb000") != NULL);
    panic_render(&fb, &r);
    write_ppm(&fb, "panic_pf_1280x800");

    /* a no-error-code vector and a wide range of vectors must all format */
    for (unsigned v = 0; v < 32; v++) {
        f.vector = v;
        panic_build_exception_report(&r, &f, &cr);
        CHECK(r.nlines > 10 && strstr(r.lines[0], exception_name(v)) != NULL);
    }
    free(mem);
}

int main(int argc, char **argv)
{
    if (argc > 1) outdir = argv[1];
    layout_sweep();
    scenario("boot_1280x800_bgrx", 1280, 800, &BGRX, 0);
    scenario("boot_800x600_bgrx", 800, 600, &BGRX, 0);
    scenario("boot_640x480_bgrx", 640, 480, &BGRX, 0);
    scenario("boot_1920x1080_rgbx", 1920, 1080, &RGBX, 0);
    scenario("boot_1024x768_rgb24_padded_pitch", 1024, 768, &RGB24, 48);
    scenario("boot_1024x768_rgb565", 1024, 768, &RGB565, 0);
    missing_framebuffer();
    font_sheet();
    panic_screen();
    TEST_DONE("test_render");
}
