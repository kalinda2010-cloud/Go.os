/* Differential test: kernel kprintf vs the host libc snprintf. */
#include "kprintf.h"
#include "test_common.h"
#include <limits.h>
#include <string.h>

#define T(...)                                                                       \
    do {                                                                             \
        char a[160], b[160];                                                         \
        int ra = snprintf(a, sizeof a, __VA_ARGS__);                                 \
        int rb = ksnprintf(b, sizeof b, __VA_ARGS__);                                \
        t_total++;                                                                   \
        if (ra != rb || strcmp(a, b)) {                                              \
            t_fail++;                                                                \
            printf("  FAIL line %d: libc=[%s](%d) kernel=[%s](%d)\n", __LINE__, a, ra, b, rb); \
        }                                                                            \
    } while (0)

int main(void)
{
    T("plain text");
    T("%%|%c|%5c|%-5c|", 'x', 'y', 'z');
    T("%d|%i|%5d|%-5d|%05d|%d", 42, -42, 42, 42, 42, 0);
    T("%d|%d|%u", INT_MIN, INT_MAX, UINT_MAX);
    T("%ld|%lld|%lu|%llu", LONG_MIN, LLONG_MIN, ULONG_MAX, ULLONG_MAX);
    T("%x|%X|%08x|%-8x|", 0xbeef, 0xBEEF, 0x1234, 0x1234);
    T("%llx|%016llx|%lx", 0xffff800000000000ULL, 0x1ULL, 0xdeadbeefUL);
    T("%o|%5o", 8, 64);
    T("%s|%10s|%-10s|%.3s|%10.3s|", "hello", "hello", "hello", "hello", "hello");
    T("%zu|%zx|%hhu|%hu|%hd", (size_t)123, (size_t)255, 300, 70000, 40000);
    T("%05d|%5s|%-5d|", -7, "ab", -7);
    T("%*d|%-*d|%.*s|", 6, 5, 6, 5, 2, "abcdef");
    T("%.0d|%.5d|%8.5d|", 0, 42, 42);
    T("[%s]", "");
    {
        int x;
        char a[64], b[64];
        snprintf(a, sizeof a, "%p", (void *)&x);
        ksnprintf(b, sizeof b, "%p", (void *)&x);
        t_total++;
        if (strcmp(a, b)) { t_fail++; printf("  FAIL %%p: [%s] vs [%s]\n", a, b); }
    }
    /* truncation and size-0 behaviour */
    {
        char b[8];
        int r = ksnprintf(b, sizeof b, "%s", "0123456789");
        CHECK(r == 10);
        CHECK(strcmp(b, "0123456") == 0);
        char c[4] = { 'x', 'x', 'x', 'x' };
        r = ksnprintf(c, 0, "%d", 12345);
        CHECK(r == 5 && c[0] == 'x');
        CHECK(ksnprintf(NULL, 0, "%s", "abc") == 3);
        char n[16];
        ksnprintf(n, sizeof n, "%s", (char *)0);
        CHECK(strcmp(n, "(null)") == 0);
    }
    TEST_DONE("test_kprintf");
}
