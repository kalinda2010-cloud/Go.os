/*
 * Test harness: fakes "the CPU just took an exception" in user space.
 *
 * void isr_harness_run(void *stub, uint64_t has_err, uint64_t errcode,
 *                      const uint64_t in[15], uint64_t out[15]);
 *   in/out order: rax rbx rcx rdx rsi rdi rbp r8..r15
 * It loads every GPR from `in`, builds the exact frame the CPU would push
 * (SS,RSP,RFLAGS,CS,RIP[,errcode]) 16-byte aligned, jumps to the real ISR stub,
 * and lets the stub's own iretq come back to .Lresume where all GPRs are saved
 * into `out`.
 */
    .text
    .globl isr_harness_run
    .globl isr_harness_resume
    .type isr_harness_run, @function
isr_harness_run:
    pushq   %rbp
    pushq   %rbx
    pushq   %r12
    pushq   %r13
    pushq   %r14
    pushq   %r15
    movq    %rsp, %rax              /* original rsp */
    subq    $32, %rsp
    andq    $-16, %rsp              /* SA: aligned save area */
    movq    %r8, 0(%rsp)            /* SA+0: out pointer */
    movq    %rax, 8(%rsp)           /* SA+8: original rsp */
    movq    %rsp, %r9               /* frame RSP field = SA */

    movq    %ss, %rax
    pushq   %rax                    /* SS */
    pushq   %r9                     /* RSP */
    pushfq                          /* RFLAGS */
    movq    %cs, %rax
    pushq   %rax                    /* CS */
    leaq    isr_harness_resume(%rip), %rax
    pushq   %rax                    /* RIP */
    testq   %rsi, %rsi
    jz      1f
    pushq   %rdx                    /* error code (only for vectors that have one) */
1:
    pushq   %rdi                    /* stub address: "ret" below jumps there */

    movq    0(%rcx), %rax
    movq    8(%rcx), %rbx
    movq    24(%rcx), %rdx
    movq    32(%rcx), %rsi
    movq    40(%rcx), %rdi
    movq    48(%rcx), %rbp
    movq    56(%rcx), %r8
    movq    64(%rcx), %r9
    movq    72(%rcx), %r10
    movq    80(%rcx), %r11
    movq    88(%rcx), %r12
    movq    96(%rcx), %r13
    movq    104(%rcx), %r14
    movq    112(%rcx), %r15
    movq    16(%rcx), %rcx
    ret                             /* -> stub, rsp now at the fake frame */

isr_harness_resume:
    pushq   %rax
    movq    8(%rsp), %rax           /* out pointer */
    movq    %rbx, 8(%rax)
    movq    %rcx, 16(%rax)
    movq    %rdx, 24(%rax)
    movq    %rsi, 32(%rax)
    movq    %rdi, 40(%rax)
    movq    %rbp, 48(%rax)
    movq    %r8, 56(%rax)
    movq    %r9, 64(%rax)
    movq    %r10, 72(%rax)
    movq    %r11, 80(%rax)
    movq    %r12, 88(%rax)
    movq    %r13, 96(%rax)
    movq    %r14, 104(%rax)
    movq    %r15, 112(%rax)
    movq    (%rsp), %rbx
    movq    %rbx, 0(%rax)           /* original rax */
    addq    $8, %rsp
    movq    8(%rsp), %rsp           /* back to the pre-alignment stack */
    popq    %r15
    popq    %r14
    popq    %r13
    popq    %r12
    popq    %rbx
    popq    %rbp
    ret
    .size isr_harness_run, . - isr_harness_run
    .section .note.GNU-stack,"",@progbits
